**Automation WebApplication Execution**

**Getting Started**

Sample Test suite for web application automation project having dependency on the Selenium Framework.

**Prerequisites**

•Maven 3.3.9 •Git 2.15.1 •JDK 1.8 •Chrome Browser •Firefox Browser •IE Browser •Android Chrome Browser •IOS Safari Browser
•Android App •IOS App

**Installing**

Please follow the instructions from confluence page http://azuwvdsstmcd02.mfcgd.com:23860/display/QTD/Framework+Setup

**Scripting**

Please refer the confluence page for best practices and code conventions: http://azuwvdsstmcd02.mfcgd.com:23860/pages/viewpage.action?pageId=59377359

**Java Selenium Page Objects**

- All selenium page objects exist in
  src/main/java/com/manulife/automation/selenium_execution/pages/
  pages class name should reflect the page name

**Page Object without Page Factory:**

1.All selenium based actions should be performed within the DriverUtil class


2.Class name should reflect the page name and under that class all variables should be declared as private String and all functions should be public


3.All util functions are exist in core framework, it extended in DriverUtil class to access the generic functions


Example: public class DriverUtil extends DriverUtilBase { }

Example code:
public class ClientBillsPage {  
private DriverUtil driverUtil;
private String linkPayeeXPath = "//a[@id=\"id_Add_Payee\"]";
public void clickAddPayee() throws Exception {      
    this.driverUtil.clickWithExecutionTimeout(By.xpath(linkPayeeXPath));    
}

**Test Classes**

1.All test classes exist in src/test/java/com/manulife/automation/selenium_execution/tests/


2.Every test method is decorated with @Test annotation


3.Ideally no selenium based actions are performed in the test method. All actions to be performed using the methods of the page objects


**browserTestSuite.xml  appTestSuite.xml**

1.Define the test suite using the ... tags. Attributes include 'name', 'verbose' A suite can contain multiple tests


2.Define the test within the suite using the ... tags with the attribute 'name' A test can have multiple test classes within it


3.Add test classes using .... tags with the attribute 'name'. All these test classes will be enclosed within 


4.Any parameters at the test level or test class level are to be enclosed within with the attributes 'name' and 'value'


**How to Run:**

 1. Using parameter when executing from command line
 
    	- mvn clean install (by default it would run on chrome)
    	OR
    	- mvn clean install -Dbrowser=chrome (you can pass browser as parameter)
 
 2. You can setup mvn run configuration
 
  		- setup Goals: clean install (by default it would run on chrome)
		OR
 		- setup Goals: clean install and add Parameter: Name=browser and Value=chrome (you can pass browser as parameter)
 		
**Run Tests in Different Environments:**

If user wants to run the test by passing the environment from command line or Jenkins then they need to set the "environment" parameter with the environment name used for execution. User need to ensure the environment is present within config.xml file.

To run from command prompt or maven goals within Eclipse please use the following command. Based on the below command it will take the environment for QA-1 from config.xml file.

	mvn install -Denvironment="QA-1"

**Test Case Execution for Different Browser:**

For Web Browser testing user can provide the browser from command line or Jenkins or this can be supplied from config xml file. To supply the browser information from maven command user needs to specify the "browser" parameter using following way.
	
	mvn install -Dbrowser="Chrome"

As of now the supported browsers for Next Gen framework are "chrome", "firefox", "ie".

If the user will not supply any browser from command line then the framework will read the browser information from config XML file. User has to keep the "defaultTargetMedium" key under framework settings as "webBrowser" to run the test using Desktop Browser.

```java
	<generalSettings>
    	<frameworkSettings key="defaultTargetMedium" value="webBrowser"/> 
   </generalSettings>
```

Once the Target Medium is set to webBrowser then user has to provide the value of the Target medium as chrome or ie or firefox within TargetMedium settings. When user will supply the browser from command then that will overwrite the value present within config XML file.

```java
	<targetMediums>
  	  	<targetMedium key="webBrowser" browserTested="chrome"/> 
   </targetMediums>
```

**Test Case Execution for Different Language:**

Users can runs different test cases within different language by supplying "language" parameter from maven command or Jenkins Parameter.

	mvn install -Dlanguage="english"

At present the framework is only supporting English and French. Within the parameter you need to provide either "english" or "french".

By default framework will take the default language from the config XML if nothing will be passed from command. Within the config XML you will find the defaultlanguage tag within frameworksettings with tag name "defaultLanguage". User can change the value of the key to run the test with different language. The below XML snippet shows the language settings for english. If user wants to run it within French then they need to specify the value as "french".

```java
	<generalSettings>
        <frameworkSettings key="defaultLanguage" value="english"/>
   </generalSettings>
```

If the user will provide any language from command then that will overwrite the language specified within config XML file.
		
**Run Groups of Tests Using Automation Tags:**

Users can runs groups of automated test cases by tagging each test case with a test type such as smoke, regression, release, etc. The test types are configured in the TestType class under the common package in this project. Call the tag in the test annotation above the test class to use it:
    
    @Test(groups=TestType.SMOKE)

To run a group of automated tests from command prompt or maven goals within Eclipse please use the following command:

    mvn install -Dautomation.group=Smoke


**Run the Test within Firefox Browser:**

To run the test within Firefox browser you need to provide the path of the Firefox executable within the config.xml file. If Firefox is installed properly within your system i.e. at C:\Program Files then it will launch the Firefox browser without any issue. You need to ensure customPath key within browser tag is kept as false.But, if that is not installed then you need to make the customPath key as True and provide the executable location within exePath key.

For running through Jenkins it is recommended to make the customPath key as false as Linux box will automatically handle this. For Windows Slave user needs to update the config file and then run the test.

**Automation Web or Native Application Execution within Perfecto Mobile**

**Pre-Requisite to run on Perfecto Cloud:**

Before you run on Perfecto Cloud you need to provide the Perfecto Cloud information within the config file so that Framework can connect the device to run the test. Fill up data within Perfecto mobile section as shown below.

```java
	<MobileSettings>
		<Perfecto>
			<mSettings key="hostUrl" value="https://manulife.perfectomobile.com/nexperience" />
			<mSettings key="userName" value="Perfecto User Name"/>
			<mSettings key="pwd" value="Perfecto Password"/>
			<mSettings key="androidDeviceID" value="Android Device ID"/>
			<mSettings key="appPackageName" value="Android Application Package Name"/>
			<mSettings key="iOSDeviceID" value="iOS Device ID"/>
			<mSettings key="appBundleID" value="iOS Application Package Name"/>
			<mSettings key="iOSBrowser" value="Safari"/>
			<mSettings key="androidBrowser" value="Chrome"/>
		</Perfecto>
	</MobileSettings>
```

**Test Case Execution for Mobile WebApplication:**

For Web Browser testing you can run the same test case that you have designed for Desktop Browser. You just need to specify the Mobile Browser to execute on Mobile Platform. To run the test within Mobile browser either you can provide the browser name from Maven Command or you can specify the browser within config xml file. The below example show you the section of config file where you need to specify the browser information and target platform to run the test on Android or iOS Device. The acceptable value of the browser is android_chrome or ios_safari.

You need to ensure that the "defaultTargetMedium" is set to "webMobile" when supplying the browser from Maven command.

```java
	<generalSettings>
    	<frameworkSettings key="defaultTargetMedium" value="webMobile"/> 
   </generalSettings>
   <targetMediums>
	  	<targetMedium key="webMobile" browserTested="android_chrome"/> 
   </targetMediums>
```
   
**Test Case Execution for Mobile Native Application:**

For Mobile Native Application you need to create separate Test Case by extending MobileBaseTest Class.

You need to make sure the application is installed on the device that you are going to use for execution. Provide the application package name and the device ID within the specific section of config file as shown above.

Once the Test case design is done then you can execute the test by specifying the mobile app browser either from Maven command or config file. The acceptable value of the browser is android_device or ios_device.

You need to ensure that the "defaultTargetMedium" is set to "appMobile" when supplying the browser from Maven command.

```java
	<generalSettings>
    	<frameworkSettings key="defaultTargetMedium" value="appMobile"/> 
   </generalSettings>
	<targetMediums>
      	<targetMedium key="appMobile" browserTested="android_device"/>
   </targetMediums>
```