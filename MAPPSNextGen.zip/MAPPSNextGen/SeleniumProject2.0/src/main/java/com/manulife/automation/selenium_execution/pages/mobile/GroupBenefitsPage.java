package com.manulife.automation.selenium_execution.pages.mobile;

import org.openqa.selenium.By;

import com.manulife.automation.selenium_core.utils.reports.ExtentManager;
import com.manulife.automation.selenium_execution.utils.MobileDriverUtil;
import com.relevantcodes.extentreports.LogStatus;

public class GroupBenefitsPage {	
	private MobileDriverUtil mobileDriverUtil;
	
	private String linkGroupBenefitXPath = "//*[@text='Group Benefits' or @label='Group Benefits']";
	private String editPlanContactNumberXPath = "//*[@resource-id='ca.manulife.MobileGBRS:id/input_plan' or @content-desc='Plan contract number'] | //*[@label='Plan contract number']/following-sibling::XCUIElementTypeTextField";
	private String editMemberCertificateNumberXPath = "//*[@resource-id='ca.manulife.MobileGBRS:id/input_member' or @content-desc='Member certificate number'] | //*[@label=\"Member certificate number\"]/following-sibling::XCUIElementTypeTextField";
	
	public GroupBenefitsPage(MobileDriverUtil mobileDriverUtil) throws Exception{		
		this.mobileDriverUtil = mobileDriverUtil;		
	}	
	
	public void goToGroupBenefits() {
		try {
			this.mobileDriverUtil.clickwithWebDriver(By.xpath(linkGroupBenefitXPath));
			ExtentManager.reportlog(LogStatus.PASS, "Clicked on Group Benefits", true);
		}
		catch (Exception e)
		{
			ExtentManager.reportlog(LogStatus.FAIL, "Unable to click on Group Benefits", true);
		}
	}
	
	public void loginToApplication() {
		try {
			this.mobileDriverUtil.clickwithWebDriver(By.xpath(editPlanContactNumberXPath));
			this.mobileDriverUtil.clear(By.xpath(editPlanContactNumberXPath));
			this.mobileDriverUtil.sendKeys(By.xpath(editPlanContactNumberXPath), "152928988");	
			this.mobileDriverUtil.clickwithWebDriver(By.xpath(editMemberCertificateNumberXPath));
			this.mobileDriverUtil.clear(By.xpath(editMemberCertificateNumberXPath));
			this.mobileDriverUtil.sendKeys(By.xpath(editMemberCertificateNumberXPath), "12345678");
			ExtentManager.reportlog(LogStatus.PASS, "Certification Number entered successfully", true);
		}
		catch (Exception e){
			ExtentManager.reportlog(LogStatus.FAIL, "Unable to login", true);
		}
	}
	
	
}