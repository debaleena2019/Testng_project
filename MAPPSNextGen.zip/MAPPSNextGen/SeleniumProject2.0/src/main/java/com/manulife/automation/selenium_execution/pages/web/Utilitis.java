/**
 * 
 */
package com.manulife.automation.selenium_execution.pages.web;
 


import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import com.manulife.automation.selenium_core.utils.ImageCompareUtil;
import com.manulife.automation.selenium_core.utils.reports.ExtentManager;
//import com.manulife.automation.selenium_execution.tests.web.Set;
import com.manulife.automation.selenium_execution.utils.DriverUtil;
import com.relevantcodes.extentreports.LogStatus;
import java.awt.Robot;
import java.awt.event.KeyEvent;

public class Utilitis {	
	private DriverUtil driverUtil;
	
	WebElement element= null;
	
	ImageCompareUtil imageCompare = new ImageCompareUtil();
	
	private String OpenNavigator = "//*[@value='Open Navigator']";
	private String UnlockAccount = "//*[@value='Unlock Account']";
	private String UtilitisLink= "(//*[@class='data-module-link'])[3]";
	private String PolicyInquiryLink= "(//*[@class='data-module-link'])[2]";
	private String PolicySearchButton= "(//*[@id='btnSearch'])";
	private String TableMaintenanceLink= "//*[text()='Table Maint.']"; 
	private String Addbutton="//*[@id='btnAdd']";
	private String savebutton="//input[@title='Save']";//
	private String closebutton="//*[@id='Close']";
	private String AddTableName="txtName";//INPUT[@id="txtName"]
	private String AddTableDesc="//*[@id='txtDesc']";
	private String AddTableLength="txtValueLength";
	private String PopUpOkButton="//*[@value='OK']";
	
	
	
	
	
	
	public Utilitis(DriverUtil driverUtil) throws Exception {
		this.driverUtil = driverUtil;		
		this.driverUtil.waitForJQueryToLoad();
	}
	
	public void ClickOnNavigator(Map<String,String> data) throws Exception{
		
		element = driverUtil.waitForElementToBeClickable(By.xpath(OpenNavigator));
			Thread.sleep(2000);
			element.click();
			WebElement element1= null;
			element1 = driverUtil.waitForElementToBeClickable(By.xpath(UnlockAccount));
			ExtentManager.reportlog(LogStatus.PASS, "Clicked the open navigator button successfully", true);
			element1.click();
			Thread.sleep(2000);
	
		
	}
	
	public void ClickOnUtilitis(Map<String,String> data) throws Exception{
		Thread.sleep(3000);
		System.out.println("Now in Utility Function");
		element = driverUtil.waitForElementToBeClickable(By.xpath(UtilitisLink));
		element.click();
			ExtentManager.reportlog(LogStatus.PASS, "Clicked the Utilities successfully", true);
			
		
	}
	
	
	public void ClickOnPolicySearchLink(Map<String,String> data) throws Exception{
		Thread.sleep(3000);
		System.out.println("Now in Policy Serach");
		element = driverUtil.waitForElementToBeClickable(By.xpath(PolicyInquiryLink));
		element.click();
		ExtentManager.reportlog(LogStatus.PASS, "Clicked the Policy Enqiry successfully", true);
			
		
	}
	
	public void ClickOnPolicySearchButton(Map<String,String> data) throws Exception{
		Thread.sleep(3000);
		System.out.println("Now in Policy Serach");
		element = driverUtil.waitForElementToBeClickable(By.xpath(PolicySearchButton));
		element.click();
		ExtentManager.reportlog(LogStatus.PASS, "Clicked the Policy search button successfully", true);
			
		
	}
		public void ClickOnTableMaintenance(Map<String,String> data) throws Exception{
				
				Thread.sleep(3000);
				element = driverUtil.waitForElementToBeClickable(By.xpath(TableMaintenanceLink));
				System.out.println("Hello1");
				element.click();
				System.out.println("Hello2");
				ExtentManager.reportlog(LogStatus.PASS, "Clicked the Table Maintenance successfully", true);
				
			
		}
			
			public void ClickOnAddButton(Map<String,String> data) throws Exception{
				
				element = driverUtil.waitForElementToBeAppear(By.xpath("//*"));
				System.out.println(element.getText());
				element = driverUtil.waitForElementToBeClickable(By.xpath(Addbutton));
				
				if(element!=null) {
					element.click();
					ExtentManager.reportlog(LogStatus.PASS, "Clicked the Add button", true);
					
				}
				
				
			}
				public void SavewithNullValue(Map<String,String> data)  {
				try {	
					
					element = driverUtil.getDriver().findElement(By.id(savebutton));
					element.click();
					driverUtil.alertAccept();
					//steps after switch to window
					element = driverUtil.getDriver().findElement(By.id(AddTableName));
					element.sendKeys("ABC", Keys.TAB);
					element = driverUtil.getDriver().findElement(By.id(savebutton));
					element.click();
					driverUtil.alertAccept();
					Thread.sleep(2000);
				   } catch (Exception e) {
					// TODO: handle exception
					System.out.println("exception  "+e);
				}
							
              
	}
	
		
	
}