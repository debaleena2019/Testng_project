package com.manulife.automation.selenium_execution.pages.web;

import java.util.List;

import org.openqa.selenium.By;
import org.testng.Assert;
import com.manulife.automation.selenium_core.utils.ImageCompareUtil;
import com.manulife.automation.selenium_core.utils.reports.ExtentManager;
import com.manulife.automation.selenium_execution.utils.DriverUtil;
import com.relevantcodes.extentreports.LogStatus;

public class AutomationPracticePage {	
	private DriverUtil driverUtil;
	
	ImageCompareUtil imageCompare = new ImageCompareUtil();
	private String inputSearchXPath = "//input[@id='search_query_top']";
	private String buttonSearchXPath = "//button[@name='submit_search']";
	private String serachProductXPath = "(//*[@class='product-name' and contains(text(),'%%PRODUCT')])[1]";
	private String menuWomenTabXPath = "//a[contains(@title, 'Women')]";
	private String signInXPath = "//a[contains(@class, 'login')]";
	private String tabWomenNavigationXPath = "//*[@class='navigation_page']";
	private String menuCategoryTextStr = "CATEGORIES";
	
	public AutomationPracticePage(DriverUtil driverUtil) throws Exception{		
		this.driverUtil = driverUtil;		
		this.driverUtil.waitForJQueryToLoad();
	}		
	
	public void verifyMenuCategory() throws Exception{
		Assert.assertNotNull(this.driverUtil.waitForElementToBeVisible(By.xpath(this.signInXPath)));
		
		//For Mobile browser the orientation is different and we have to click on Category Link first
		if(this.driverUtil.isAndroid() || this.driverUtil.isIOS()) {
			this.driverUtil.clickWithPerfectoOCR(this.menuCategoryTextStr);
		}
		
		Assert.assertNotNull(this.driverUtil.waitForElementToBeVisible(By.xpath(this.menuWomenTabXPath)));
		this.driverUtil.clickwithWebDriver(By.xpath(this.menuWomenTabXPath));
		Assert.assertNotNull(this.driverUtil.waitForElementToBeAppear(By.xpath(this.tabWomenNavigationXPath)));
	}
	
	public List<Double> getMatchedPercentage() throws Exception {
		String screenshotPathName = this.driverUtil.takeScreenshotAndMoveToAbsolutePath();
		List<Double> matchPercentage = imageCompare.compareTwoImagesForSimilarity("images/logo.jpg", screenshotPathName);
		return matchPercentage;
	}
	
	public void searchProduct(String productNameStr) {
		this.driverUtil.sendKeys(By.xpath(this.inputSearchXPath), productNameStr);
		ExtentManager.reportlog(LogStatus.PASS, "Entered product "+productNameStr, true);
		this.driverUtil.click(By.xpath(this.buttonSearchXPath));
	}
	
	public ProductDetailsPage selectProduct(String productNameStr) throws Exception {
		String productXPath = this.serachProductXPath.replaceAll("%%PRODUCT", productNameStr);
		this.driverUtil.waitForElementToBeVisible(By.xpath(productXPath));
		this.driverUtil.click(By.xpath(productXPath));
		ExtentManager.reportlog(LogStatus.PASS, "Clicked on Product "+productNameStr, true);
		return new ProductDetailsPage(this.driverUtil);
	}
	
	
	
}