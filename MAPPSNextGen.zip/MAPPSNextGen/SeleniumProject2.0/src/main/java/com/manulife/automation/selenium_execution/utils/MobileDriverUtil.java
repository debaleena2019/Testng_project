package com.manulife.automation.selenium_execution.utils;


import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import com.manulife.automation.selenium_core.utils.MobileDriverUtilBase;
import io.appium.java_client.AppiumDriver;
/**
 * Grouping of all MobileDriver Util wrapper methods
 *
 * @author Sarbjit Sandhu
 */
public class MobileDriverUtil extends MobileDriverUtilBase {
	protected static final Logger logger = LogManager.getLogger(MobileDriverUtil.class.getName());

	/**
	 * MobileDriverUtil Class Constructor
	 *
	 * @param newDriver - AppiumDriver to be used locator this class
	 */
	@SuppressWarnings("rawtypes")
	public MobileDriverUtil(AppiumDriver newDriver) {
		super(newDriver);
		this.mobileDriver = newDriver;
	}
	
}
