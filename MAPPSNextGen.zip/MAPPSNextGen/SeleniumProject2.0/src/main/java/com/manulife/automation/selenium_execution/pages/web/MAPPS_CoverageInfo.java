/**
 * 
 */
package com.manulife.automation.selenium_execution.pages.web;
 


import java.util.List;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.manulife.automation.selenium_core.driver.web.DriverThreadManager;
import com.manulife.automation.selenium_core.utils.ImageCompareUtil;
import com.manulife.automation.selenium_core.utils.reports.ExtentManager;
//import com.manulife.automation.selenium_execution.tests.web.Set;
import com.manulife.automation.selenium_execution.utils.DriverUtil;
import com.relevantcodes.extentreports.LogStatus;


import java.awt.Robot;
import java.awt.event.KeyEvent;

public class MAPPS_CoverageInfo {	
	private DriverUtil driverUtil;
	
	WebElement element= null;
	
	ImageCompareUtil imageCompare = new ImageCompareUtil();
	
	private String HomePageLink= "(//*[@id='menutab1'])";
	private String CoverageInfo= "(//*[@id='menutab2'])";
	private String CopyModel= "(//*[@id='cCopyModel'])";
	private String PublicationOperation= "(//*[@id='menutab5'])";
	private String Archieving= "(//*[@id='cMG_Archive'])";
	private String ContraxtNumberTextBox= "(//*[@id='txtDraftContractNumber'])";
	private String LookUpbtn= "(//*[@title='Look Up'])";
	private String NewContract= "(//*[@class='roundRight'])[3]";
	private String ChangeEffectivedatelink= "(//*[@id='cChangeEffectiveDate'])";
	private String ContractNumberField= "(//*[@id='txtContractNumber'])";
	private String DateInputField= "(//*[@id='txtEffectiveDate-input'])";
	private String OKbtn= "(//*[@span='OK'])";	
	private String PublicationInfo= "(//*[@id='menutab3'])";
	private String BookletListing= "(//*[@id='cbookletListing'])";
	private String contractNum= "(//*[@id='txtContractNumber'])";
	private String LookUp= "(//*[@class='roundRight'])[1]";
	private String StatusReset= "(//*[@id='InitiateAmendment1'])";
	private String StatusResetLink= "(//*[@id='InitiateStatusReset'])";
	private String OkButton= "//*[@alt='OK']";
	
private WebDriver driver = DriverThreadManager.getDriverStatic();
	
	
	public MAPPS_CoverageInfo(DriverUtil driverUtil) throws Exception {
		this.driverUtil = driverUtil;		
		this.driverUtil.waitForJQueryToLoad();
	}
	
	public WebDriver getDriver()
	{
		return DriverThreadManager.getDriverStatic();
	} 
	
	public void ClickOnPublicationInfo(Map<String,String> data) throws Exception{
		
			element = driverUtil.waitForElementToBeClickable(By.xpath(PublicationInfo));
			Thread.sleep(2000);
			element.click();
			WebElement element1= null;
			
			element1 = driverUtil.waitForElementToBeClickable(By.xpath(BookletListing));
			element1.click();
			ExtentManager.reportlog(LogStatus.PASS, "Clicked the open navigator button successfully", true);
			Thread.sleep(2000);
			
			element = driverUtil.getWebElement(By.xpath(contractNum));
			Thread.sleep(2000);
			
			element.sendKeys(data.get("ContractNumber"));
			
			element = driverUtil.waitForElementToBeClickable(By.xpath(LookUp));
			Thread.sleep(2000);
			element.click();
		
	}
	
		public void ClickOnPublicationOperation(Map<String,String> data) throws Exception{
		
			element = driverUtil.waitForElementToBeClickable(By.xpath(PublicationOperation));
			Thread.sleep(2000);
			element.click();
			WebElement element1= null;
			
			element1 = driverUtil.waitForElementToBeClickable(By.xpath(Archieving));
			element1.click();
			ExtentManager.reportlog(LogStatus.PASS, "Clicked the archiving link successfully", true);
			Thread.sleep(2000);
			
			element = driverUtil.waitForElementToBeAppear(By.xpath(contractNum));
			Thread.sleep(2000);
			element.clear();
			element.sendKeys(data.get("ContractNumber"));
			
			element = driverUtil.waitForElementToBeClickable(By.xpath(LookUp));
			Thread.sleep(2000);
			element.click();
	
		}
		
		public void ClickOnCoverageInformation(Map<String,String> data) throws Exception{
			
			element = driverUtil.waitForElementToBeClickable(By.xpath(CoverageInfo));
			Thread.sleep(2000);
			element.click();
			ExtentManager.reportlog(LogStatus.PASS, "Clicked the archiving link successfully", true);
		}	
		
		public void ClickOnStatusReset(Map<String,String> data) throws Exception{
			
			element = driverUtil.waitForElementToBeClickable(By.xpath(StatusReset));
			Thread.sleep(2000);
			element.click();
			element = driverUtil.waitForElementToBeClickable(By.xpath(StatusResetLink));
			Thread.sleep(2000);
			element.click();
			ExtentManager.reportlog(LogStatus.PASS, "Clicked the link successfully", true);
			element = driverUtil.getWebElement(By.xpath(contractNum));
			Thread.sleep(2000);
			
			element.sendKeys(data.get("ContractNumber"));
			
			element = driverUtil.waitForElementToBeClickable(By.xpath(OkButton));
			Thread.sleep(2000);
			element.click();
			driverUtil.alertAccept();
			
			element = driverUtil.waitForElementToBeClickable(By.xpath(HomePageLink));
			Thread.sleep(2000);
			element.click();
			
			element = driverUtil.waitForElementToBeClickable(By.xpath(ContractNumberField));
			Thread.sleep(2000);
			element.sendKeys(data.get("ContractNumber"));
			
			/*element = driverUtil.waitForElementToBeClickable(By.xpath(OkButton));
			Thread.sleep(2000);*/
			//element.click();
			
			List<WebElement> Ele = driverUtil.getDriver().findElements(By.xpath(OkButton));
			int i=Ele.size();
			for (i=1;i<=2;i++) {
				if (i==2) {
					
					Ele.get(i).click();
					
				}
				
			}
		}

	
	
}
	
		
	
