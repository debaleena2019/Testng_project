/**
 * 
 */
package com.manulife.automation.selenium_execution.pages.web;
 


import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import com.manulife.automation.selenium_core.utils.ImageCompareUtil;
import com.manulife.automation.selenium_core.utils.reports.ExtentManager;
//import com.manulife.automation.selenium_execution.tests.web.Set;
import com.manulife.automation.selenium_execution.utils.DriverUtil;
import com.relevantcodes.extentreports.LogStatus;
import java.awt.Robot;
import java.awt.event.KeyEvent;

public class PolicySearch {	
	private DriverUtil driverUtil;
	
	WebElement element= null;
	
	ImageCompareUtil imageCompare = new ImageCompareUtil();
	
	private String OpenNavigator = "//*[@value='Open Navigator']";
	private String UnlockAccount = "//*[@value='Unlock Account']";
	private String LogoutLink = "//*[@class='logoutHome']";
	private String PolicyInquiryLink= "(//*[@class='data-module-link'])[2]";
	private String PolicySearchButton= "(//*[@id='btnSearch'])";
	private String PopUpOkButton="//*[@value='OK']";
	private String TxtPolicyNumber="(//*[@id='txtPolicyNo'])";
	private String ChckboxPolicyNumber="(//*[@id='chkIncludeCancelled'])";
	private String PolicyGrid="(//*[@class='t-state-selected'])";
	private String PolicyGetButton="(//*[@id='btnGetPolicy'])";
	private String DivisionButton="(//*[@id='btnDivision'])";
	private String AMSBenefit="(//*[@id='btnAMSBenefit'])";
	private String NarrativeButton= "(//*[@id='btnNarative'])";
	private String DivisionNarrativeButton= "(//*[@id='btnnaraative'])"; //btnnarrative
	private String Narrative= "(//*[@id='btnnarrative'])";
	private String EarlierButton= "(//*[@id='btnEarlier'])";
	private String LaterButton= "(//*[@id='btnLater'])";
	private String Bulletin= "(//*[@id='btnBulletin'])";
	private String MailArrangement= "(//*[@id='btnMailArrangement'])";
	private String ClaimRespButton= "(//*[@id='btnClaimResp'])";
	private String LTDBenefit= "(//*[@id='btnLTDBenefit'])";
	private String STDBenefit= "(//*[@id='btnSTDBenefit'])";
	private String LifeBenefit= "(//*[@id='btnLIFEBenefit'])";
	private String CovTaxButton= "(//*[@id='btnCovTax'])";
	private String CloseButton= "(//*[@id='btnClose'])";
	private String ClassButton= "(//*[@id='btnClass'])";
	private String SIBButton= "(//*[@id='btnSIBBenefit'])";
	private String DivisionRecord = "(//*[contains(@style,'white')][@class='gridNumericColumn'])[1]";
	private String DivisionClose = "(//*[@id='btnCloseDetail'])";
	private String PreDiv = "(//*[@id='btnPrevDiv'])";
	private String PreDiv1 = "(//*[@id='btnPrev'])";
	private String NxtDiv = "(//*[@id='btnNextDiv'])";
	private String NxtDiv1 = "(//*[@id='btnNext'])";
	private String btnGetMailArrDet = "(//*[@id='btnGetMailArrDet'])";
	private String btnNextMail = "(//*[@id='btnNextMailArr'])";
	private String btnCloseMail = "(//*[@id='btnCloseDetail'])";
	private String btnPrevMail = "(//*[@id='btnPrevMailArr'])";
	private String btnGetClass = "(//*[@id='btnGetClass'])";
	private String GetSTDButton = "(//*[@id='btnGetSTDBenefitDetail'])";
	private String GetLTDButton = "(//*[@id='btnGetLTDBenefitDetail'])";
	private String EntitlementTab = "(//*[@id='EntitlementTab'])";
	private String UnderWritingTab = "(//*[@id='WritingTab'])";
	private String OffsetTab = "(//*[@id='OffsetTab'])";
	private String UnderWritingButtonNarrative = "(//*[@id='btnnarrative'])";
	private String ButtonCloseDetails = "(//*[@id='btnCloseDetail'])";
	private String Coverage = "(//*[@class='t-link'][@href='#TabStrip-1'])";
	private String Entitlement = "(//*[@class='t-link'][@href='#TabStrip-2'])";
	private String COLA = "(//*[@class='t-link'][@href='#TabStrip-3'])";
	private String Pension = "(//*[@class='t-link'][@href='#TabStrip-4'])";
	private String Offsets = "(//*[@class='t-link'][@href='#TabStrip-5'])";
	private String Underwriting = "(//*[@class='t-link'][@href='#TabStrip-6'])";
	private String UnderWritingButtonNarrative1 = "(//*[@id='btnNarr'])";
	private String UnderWritingButtonNEarlier = "(//*[@id='btnEarlier'])";
	private String UnderWritingButtonNLater = "(//*[@id='btnLater'])";
	private String UnderWritingButtonPrev = "(//*[@id='btnPrevClass'])";
	private String UnderWritingButtonNext = "(//*[@id='btnNextClass'])";
	private String GetBenefit = "(//*[@id='btnGetBenefit'])";
	private String GetLifeBenefit = "(//*[@id='btnGetLifeBenefit'])";
	
	
	public PolicySearch(DriverUtil driverUtil) throws Exception {
		this.driverUtil = driverUtil;		
		this.driverUtil.waitForJQueryToLoad();
	}
	
	public void ClickOnNavigator(Map<String,String> data) throws Exception{
		
			element = driverUtil.waitForElementToBeClickable(By.xpath(OpenNavigator));
			Thread.sleep(2000);
			element.click();
			Thread.sleep(2000);
			element = driverUtil.waitForElementToBeClickable(By.xpath(UnlockAccount));
			element.click();
			ExtentManager.reportlog(LogStatus.PASS, "Clicked the open navigator button successfully", true);
			Thread.sleep(2000);
			element = driverUtil.waitForElementToBeVisible(By.xpath(LogoutLink));
			
			System.out.println("Exiting Click on Navigator Func.");
		
	}
	
	
	
	public void ClickOnPolicySearchLink(Map<String,String> data) throws Exception{
		Thread.sleep(3000);
		System.out.println("Now in Policy Serach");
		
		
		element = driverUtil.waitForElementToBeClickable(By.xpath(PolicyInquiryLink));
		
		if(element!=null) {
			element.click();
			ExtentManager.reportlog(LogStatus.PASS, "Clicked the Add button", true);
			
		}
				
			
		
	}
	
	public void ClickOnPolicySearchButton(Map<String,String> data) throws Exception{
		Thread.sleep(3000);
		System.out.println("Now in Policy Serach");
		element = driverUtil.waitForElementToBeClickable(By.xpath(PolicySearchButton));
		element.click();
		ExtentManager.reportlog(LogStatus.PASS, "Clicked the Policy search button successfully", true);
		Thread.sleep(5000);
		String AlertMsgActual= driverUtil.getAlertText();
		System.out.println(AlertMsgActual);
		driverUtil.alertAccept();
		String ExpectedAlertMsg="The search criteria entered returned too many records. Please refine your search by completing more fields and try again. (R-6466)";
		
			if 	(AlertMsgActual .equalsIgnoreCase(ExpectedAlertMsg)) {
			ExtentManager.reportlog(LogStatus.PASS, "Validated the popup message successfully", true);
			}
			
			element = driverUtil.waitForElementToBeClickable(By.xpath(TxtPolicyNumber));
			element.sendKeys("0901724");
			element = driverUtil.waitForElementToBeClickable(By.xpath(ChckboxPolicyNumber));
			element.click();
			element = driverUtil.waitForElementToBeClickable(By.xpath(PolicySearchButton));
			element.click();
			Thread.sleep(5000);
			
			String AlertMesgActual= driverUtil.getAlertText();
			System.out.println(AlertMesgActual);
			driverUtil.alertAccept();
			String ExpectedAlertMesg="Policy matching specified Search criteria not found.(6200)";
			
			if 	(AlertMesgActual .equalsIgnoreCase(ExpectedAlertMesg)) {
				ExtentManager.reportlog(LogStatus.PASS, "Validated the popup message successfully", true);
				}
					element = driverUtil.waitForElementToBeClickable(By.xpath(TxtPolicyNumber));
					element.sendKeys("0901724");
					element = driverUtil.waitForElementToBeClickable(By.xpath(ChckboxPolicyNumber));
					element.click();
					element = driverUtil.waitForElementToBeClickable(By.xpath(PolicySearchButton));
					element.click();
					Thread.sleep(5000);
					element = driverUtil.waitForElementToBeAppear(By.xpath(PolicyGrid));
					
					if(element!=null) {
						
						ExtentManager.reportlog(LogStatus.PASS, "Clicked the Add button", true);
						
					}
						element = driverUtil.waitForElementToBeClickable(By.xpath(PolicyGetButton));
						element.click();
						Thread.sleep(5000);
						
						element = driverUtil.waitForElementToBeAppear(By.xpath(DivisionButton));
						
						if(element!=null) {
							
							ExtentManager.reportlog(LogStatus.PASS, "Policy Detail Displayed successfully", true);
							
						}
					
				
					
			}
							
	public void ClickOnPolicySearchButtonTC02(Map<String,String> data) throws Exception{
		Thread.sleep(3000);
		System.out.println("Now in Policy Serach");
		element = driverUtil.waitForElementToBeClickable(By.xpath(PolicySearchButton));
		element.click();
		ExtentManager.reportlog(LogStatus.PASS, "Clicked the Policy search button successfully", true);
		Thread.sleep(5000);
		String AlertMsgActual= driverUtil.getAlertText();
		System.out.println(AlertMsgActual);
		driverUtil.alertAccept();
		String ExpectedAlertMsg="The search criteria entered returned too many records. Please refine your search by completing more fields and try again. (R-6466)";
		
			if 	(AlertMsgActual .equalsIgnoreCase(ExpectedAlertMsg)) {
			ExtentManager.reportlog(LogStatus.PASS, "Validated the popup message successfully", true);
			}
			
			element = driverUtil.waitForElementToBeClickable(By.xpath(TxtPolicyNumber));
			String policyNumber = data.get("PolicyNumber");
			element.sendKeys(policyNumber);; //TC02
			element = driverUtil.waitForElementToBeClickable(By.xpath(PolicySearchButton));
			element.click();
			Thread.sleep(5000);
				
			
			
					element = driverUtil.waitForElementToBeAppear(By.xpath(PolicyGrid));
					
					if(element!=null) {
						
						ExtentManager.reportlog(LogStatus.PASS, "Clicked the Add button", true);
						
					}
						element = driverUtil.waitForElementToBeClickable(By.xpath(PolicyGetButton));
						element.click();
						Thread.sleep(5000);
						
						element = driverUtil.waitForElementToBeAppear(By.xpath(DivisionButton));
						
						if(element!=null) {
							
							ExtentManager.reportlog(LogStatus.PASS, "Policy Detail Displayed successfully", true);
							
						}
						
				
						element = driverUtil.getWebElement(By.xpath(AMSBenefit));
						if (!element.isEnabled()); {
							ExtentManager.reportlog(LogStatus.PASS, "AMS Button is not enabled", true);
						}
						
						element =driverUtil.getWebElement(By.xpath(NarrativeButton));
						element.click();
						element =driverUtil.getWebElement(By.xpath(NarrativeButton));
						ExtentManager.reportlog(LogStatus.PASS, "Narrative Button Clicked", true);
						driverUtil.switchToNextTab();
						//driverUtil.getWebElement(locator)
						//Actions Builder= new Actions(driverUtil.getDriver());
						//Builder.sendKeys(Keys.ENTER);
						Robot robot= new Robot();
						robot.keyPress(KeyEvent.VK_ENTER);
						Thread.sleep(2000);
						driverUtil.switchToNextTab();
						/*element =driverUtil.getWebElement(By.xpath(EarlierButton));
						element.click();
						driverUtil.switchToNextTab();
						Thread.sleep(2000);
						robot.keyPress(KeyEvent.VK_ENTER);
						driverUtil.switchToNextTab();*/
						
						// Bulletin Button
						
						element =driverUtil.getWebElement(By.xpath(Bulletin));
						element.click();
						//driverUtil.switchToNextTab();
						Thread.sleep(2000);
						ExtentManager.reportlog(LogStatus.PASS, "Bulletin Button Clicked", true);
						element =driverUtil.getWebElement(By.xpath(CloseButton));
						element.click();
						
						// Mail Arrangement Button
						//driverUtil.switchToNextTab();
						element =driverUtil.getWebElement(By.xpath(MailArrangement));
						element.click();
						//driverUtil.switchToNextTab();
						Thread.sleep(2000);
						ExtentManager.reportlog(LogStatus.PASS, "Mail Arrangement Button Clicked", true);
						element =driverUtil.getWebElement(By.xpath(CloseButton));
						element.click();
						
						// Claim Response Button 
						//driverUtil.switchToNextTab();
						element =driverUtil.getWebElement(By.xpath(ClaimRespButton));
						element.click();
						//driverUtil.switchToNextTab();
						Thread.sleep(2000);
						ExtentManager.reportlog(LogStatus.PASS, "Claim Response Button Button Clicked", true);

						robot.keyPress(KeyEvent.VK_ENTER);
						//driverUtil.switchToNextTab();
						
						// LtD Benefit Button
						
						element =driverUtil.getWebElement(By.xpath(LTDBenefit));
						element.click();
						//driverUtil.switchToNextTab();
						Thread.sleep(2000);
						ExtentManager.reportlog(LogStatus.PASS, "LTD Benefit Button Clicked", true);
						element =driverUtil.getWebElement(By.xpath(CloseButton));
						element.click();
						//driverUtil.switchToNextTab();
						
						// STD Benefit
						
						element =driverUtil.getWebElement(By.xpath(STDBenefit));
						element.click();
						//driverUtil.switchToNextTab();
						Thread.sleep(2000);
						ExtentManager.reportlog(LogStatus.PASS, "STD Benefit Button Clicked", true);
						element =driverUtil.getWebElement(By.xpath(CloseButton));
						element.click();
						//driverUtil.switchToNextTab();
						
						// Life Benefit 
						element =driverUtil.getWebElement(By.xpath(LifeBenefit));
						element.click();
						//driverUtil.switchToNextTab();
						Thread.sleep(2000);
						ExtentManager.reportlog(LogStatus.PASS, "Life Benefit Button Clicked", true);
						element =driverUtil.getWebElement(By.xpath(CloseButton));
						element.click();
						//driverUtil.switchToNextTab();
						
						// Cov tax Button
						
						element =driverUtil.getWebElement(By.xpath(CovTaxButton));
						element.click();
						driverUtil.switchToNextTab();
						Thread.sleep(2000);
						ExtentManager.reportlog(LogStatus.PASS, "Coverage Button Clicked", true);
						robot.keyPress(KeyEvent.VK_ENTER);
						driverUtil.switchToNextTab();
			}
							
    				
	

			public void ClickOnPolicySearchButtonTC03(Map<String,String> data) throws Exception{
			Thread.sleep(3000);
			System.out.println("Now in Policy Serach");
			element = driverUtil.waitForElementToBeClickable(By.xpath(PolicySearchButton));
			element.click();
			ExtentManager.reportlog(LogStatus.PASS, "Clicked the Policy search button successfully", true);
			Thread.sleep(5000);
			String AlertMsgActual= driverUtil.getAlertText();
			System.out.println(AlertMsgActual);
			driverUtil.alertAccept();
			String ExpectedAlertMsg="The search criteria entered returned too many records. Please refine your search by completing more fields and try again. (R-6466)";
			
				if 	(AlertMsgActual .equalsIgnoreCase(ExpectedAlertMsg)) {
				ExtentManager.reportlog(LogStatus.PASS, "Validated the popup message successfully", true);
				}
				
				element = driverUtil.waitForElementToBeClickable(By.xpath(TxtPolicyNumber));
				String policyNumber = data.get("PolicyNumber");
				element.sendKeys(policyNumber);; 
				element = driverUtil.waitForElementToBeClickable(By.xpath(PolicySearchButton));
				element.click();
				Thread.sleep(5000);
					
				
				
						element = driverUtil.waitForElementToBeAppear(By.xpath(PolicyGrid));
						
						if(element!=null) {
							
							ExtentManager.reportlog(LogStatus.PASS, "Clicked the Add button", true);
							
						}
							element = driverUtil.waitForElementToBeClickable(By.xpath(PolicyGetButton));
							element.click();
							Thread.sleep(5000);
							
							element = driverUtil.waitForElementToBeAppear(By.xpath(DivisionButton));
							
							if(element!=null) {
								
								ExtentManager.reportlog(LogStatus.PASS, "Policy Detail Displayed successfully", true);
								
							}
							
					
							element = driverUtil.getWebElement(By.xpath(AMSBenefit));
							if (!element.isEnabled()); {
								ExtentManager.reportlog(LogStatus.PASS, "AMS Button is not enabled", true);
							}
							
							
							// Narrative Button 
							
							element =driverUtil.getWebElement(By.xpath(NarrativeButton));
							element.click();
							element =driverUtil.getWebElement(By.xpath(NarrativeButton));
							ExtentManager.reportlog(LogStatus.PASS, "Narrative Button Clicked", true);
							driverUtil.switchToNextTab();
					
							Robot robot= new Robot();
							robot.keyPress(KeyEvent.VK_ENTER);
							Thread.sleep(2000);
							driverUtil.switchToNextTab();
							
							// Bulletin Button
							
							element =driverUtil.getWebElement(By.xpath(Bulletin));
							element.click();
							//driverUtil.switchToNextTab();
							Thread.sleep(2000);
							ExtentManager.reportlog(LogStatus.PASS, "Bulletin Button Clicked", true);
							element =driverUtil.getWebElement(By.xpath(CloseButton));
							element.click();
							
							// Mail Arrangement Button
							//driverUtil.switchToNextTab();
							element =driverUtil.getWebElement(By.xpath(MailArrangement));
							element.click();
							//driverUtil.switchToNextTab();
							Thread.sleep(2000);
							ExtentManager.reportlog(LogStatus.PASS, "Mail Arrangement Button Clicked", true);
							element =driverUtil.getWebElement(By.xpath(CloseButton));
							element.click();
							
							// Claim Response Button 
						
							element =driverUtil.getWebElement(By.xpath(ClaimRespButton));
							element.click();
							//driverUtil.switchToNextTab();
							Thread.sleep(2000);
							ExtentManager.reportlog(LogStatus.PASS, "Claim Response Button Button Clicked", true);
		
							robot.keyPress(KeyEvent.VK_ENTER);
							Thread.sleep(4000);						
																					
							// Cov tax Button
							
							element =driverUtil.getWebElement(By.xpath(CovTaxButton));
							element.click();
							//driverUtil.switchToNextTab();
							Thread.sleep(2000);
							ExtentManager.reportlog(LogStatus.PASS, "Coverage Button Clicked", true);
							element =driverUtil.getWebElement(By.xpath(CloseButton));
							element.click();
							//driverUtil.switchToNextTab();
							
							// Division Button 
							
							element =driverUtil.getWebElement(By.xpath(DivisionButton));
							element.click();
							//driverUtil.switchToNextTab();
							Thread.sleep(2000);
							ExtentManager.reportlog(LogStatus.PASS, "Division Button Clicked", true);
							element =driverUtil.getWebElement(By.xpath(CloseButton));
							element.click();
							//driverUtil.switchToNextTab();
							// CLass Button
							
							element =driverUtil.getWebElement(By.xpath(ClassButton));
							element.click();
							//driverUtil.switchToNextTab();
							Thread.sleep(2000);
							ExtentManager.reportlog(LogStatus.PASS, "Class Button Clicked", true);
							element =driverUtil.getWebElement(By.xpath(CloseButton));
							element.click();
							
							
				};
				
				
				
				public void ClickOnPolicySearchButtonTC04(Map<String,String> data) throws Exception{
					Thread.sleep(3000);
					System.out.println("Now in Policy Serach");
					element = driverUtil.waitForElementToBeClickable(By.xpath(PolicySearchButton));
					element.click();
					ExtentManager.reportlog(LogStatus.PASS, "Clicked the Policy search button successfully", true);
					Thread.sleep(5000);
					String AlertMsgActual= driverUtil.getAlertText();
					System.out.println(AlertMsgActual);
					driverUtil.alertAccept();
					String ExpectedAlertMsg="The search criteria entered returned too many records. Please refine your search by completing more fields and try again. (R-6466)";
					
						if 	(AlertMsgActual .equalsIgnoreCase(ExpectedAlertMsg)) {
						ExtentManager.reportlog(LogStatus.PASS, "Validated the popup message successfully", true);
						}
						
						element = driverUtil.waitForElementToBeClickable(By.xpath(TxtPolicyNumber));
						String policyNumber = data.get("PolicyNumber");
						element.sendKeys(policyNumber);; 
						element = driverUtil.waitForElementToBeClickable(By.xpath(PolicySearchButton));
						element.click();
						Thread.sleep(5000);
							
						
						
								element = driverUtil.waitForElementToBeAppear(By.xpath(PolicyGrid));
								
								if(element!=null) {
									
									ExtentManager.reportlog(LogStatus.PASS, "Clicked the Add button", true);
									
								}
									element = driverUtil.waitForElementToBeClickable(By.xpath(PolicyGetButton));
									element.click();
									Thread.sleep(5000);
									
									element = driverUtil.waitForElementToBeAppear(By.xpath(DivisionButton));
									
									if(element!=null) {
										
										ExtentManager.reportlog(LogStatus.PASS, "Policy Detail Displayed successfully", true);
										
									}
									
							
									element = driverUtil.getWebElement(By.xpath(AMSBenefit));
									if (!element.isEnabled()); {
										ExtentManager.reportlog(LogStatus.PASS, "AMS Button is not enabled", true);
									}
									
									
									// Narrative Button 
									
									element =driverUtil.getWebElement(By.xpath(NarrativeButton));
									element.click();
									element =driverUtil.getWebElement(By.xpath(NarrativeButton));
									ExtentManager.reportlog(LogStatus.PASS, "Narrative Button Clicked", true);
									driverUtil.switchToNextTab();
							
									Robot robot= new Robot();
									robot.keyPress(KeyEvent.VK_ENTER);
									Thread.sleep(2000);
									driverUtil.switchToNextTab();
									
									// Bulletin Button
									
									element =driverUtil.getWebElement(By.xpath(Bulletin));
									element.click();
									//driverUtil.switchToNextTab();
									Thread.sleep(2000);
									ExtentManager.reportlog(LogStatus.PASS, "Bulletin Button Clicked", true);
									element =driverUtil.getWebElement(By.xpath(CloseButton));
									element.click();
									
									// Mail Arrangement Button
									//driverUtil.switchToNextTab();
									element =driverUtil.getWebElement(By.xpath(MailArrangement));
									element.click();
									//driverUtil.switchToNextTab();
									Thread.sleep(2000);
									ExtentManager.reportlog(LogStatus.PASS, "Mail Arrangement Button Clicked", true);
									element =driverUtil.getWebElement(By.xpath(CloseButton));
									element.click();
									
									// Claim Response Button 
								
									element =driverUtil.getWebElement(By.xpath(ClaimRespButton));
									element.click();
									//driverUtil.switchToNextTab();
									Thread.sleep(2000);
									ExtentManager.reportlog(LogStatus.PASS, "Claim Response Button Button Clicked", true);
				
									robot.keyPress(KeyEvent.VK_ENTER);
									Thread.sleep(4000);						
																							
									// Cov tax Button
									
									element =driverUtil.getWebElement(By.xpath(CovTaxButton));
									element.click();
									//driverUtil.switchToNextTab();
									Thread.sleep(2000);
									ExtentManager.reportlog(LogStatus.PASS, "Coverage Button Clicked", true);
									element =driverUtil.getWebElement(By.xpath(CloseButton));
									element.click();
									//driverUtil.switchToNextTab();
									
									// Division Button 
									
									element =driverUtil.getWebElement(By.xpath(DivisionButton));
									element.click();
									//driverUtil.switchToNextTab();
									Thread.sleep(2000);
									ExtentManager.reportlog(LogStatus.PASS, "Division Button Clicked", true);
									element =driverUtil.getWebElement(By.xpath(CloseButton));
									element.click();
									//driverUtil.switchToNextTab();
									// CLass Button
									
									element =driverUtil.getWebElement(By.xpath(ClassButton));
									element.click();
									//driverUtil.switchToNextTab();
									Thread.sleep(2000);
									ExtentManager.reportlog(LogStatus.PASS, "Class Button Clicked", true);
									element =driverUtil.getWebElement(By.xpath(CloseButton));
									element.click();
									
									// STD Benefit
									
									element =driverUtil.getWebElement(By.xpath(STDBenefit));
									element.click();
									//driverUtil.switchToNextTab();
									Thread.sleep(2000);
									ExtentManager.reportlog(LogStatus.PASS, "STD Benefit Button Clicked", true);
									element =driverUtil.getWebElement(By.xpath(CloseButton));
									element.click();
									//driverUtil.switchToNextTab();
									
									// Life Benefit 
									element =driverUtil.getWebElement(By.xpath(LifeBenefit));
									element.click();
									//driverUtil.switchToNextTab();
									Thread.sleep(2000);
									ExtentManager.reportlog(LogStatus.PASS, "Life Benefit Button Clicked", true);
									element =driverUtil.getWebElement(By.xpath(CloseButton));
									element.click();
									
									// LtD Benefit Button
									
									element =driverUtil.getWebElement(By.xpath(LTDBenefit));
									element.click();
									//driverUtil.switchToNextTab();
									Thread.sleep(2000);
									ExtentManager.reportlog(LogStatus.PASS, "LTD Benefit Button Clicked", true);
									element =driverUtil.getWebElement(By.xpath(CloseButton));
									element.click();
									
									// SIB Button
									
									element =driverUtil.getWebElement(By.xpath(SIBButton));
									element.click();
									//driverUtil.switchToNextTab();
									Thread.sleep(2000);
									ExtentManager.reportlog(LogStatus.PASS, "SIB Button Clicked", true);
									element =driverUtil.getWebElement(By.xpath(CloseButton));
									element.click();
									
									
									
									element =driverUtil.getWebElement(By.xpath(EarlierButton));
									element.click();
									//driverUtil.switchToNextTab();
									Thread.sleep(2000);
									ExtentManager.reportlog(LogStatus.PASS, "Earlier Date Displayed ", true);
									
									element =driverUtil.getWebElement(By.xpath(LaterButton));
									element.click();
									//driverUtil.switchToNextTab();
									Thread.sleep(2000);
									ExtentManager.reportlog(LogStatus.PASS, "Later Date Displayed ", true);
						};		
		
						
						
						public void ClickOnPolicySearchButtonTC06(Map<String,String> data) throws Exception{
							Thread.sleep(3000);
							System.out.println("Now in Policy Serach");
							element = driverUtil.waitForElementToBeClickable(By.xpath(PolicySearchButton));
							element.click();
							ExtentManager.reportlog(LogStatus.PASS, "Clicked the Policy search button successfully", true);
							Thread.sleep(5000);
							String AlertMsgActual= driverUtil.getAlertText();
							System.out.println(AlertMsgActual);
							driverUtil.alertAccept();
							String ExpectedAlertMsg="The search criteria entered returned too many records. Please refine your search by completing more fields and try again. (R-6466)";
							
								if 	(AlertMsgActual .equalsIgnoreCase(ExpectedAlertMsg)) {
								ExtentManager.reportlog(LogStatus.PASS, "Validated the popup message successfully", true);
								}
								
								element = driverUtil.waitForElementToBeClickable(By.xpath(TxtPolicyNumber));
								String policyNumber = data.get("PolicyNumber");
								element.sendKeys(policyNumber);; 
								element = driverUtil.waitForElementToBeClickable(By.xpath(PolicySearchButton));
								element.click();
								Thread.sleep(5000);
									
								
								
										element = driverUtil.waitForElementToBeAppear(By.xpath(PolicyGrid));
										
										if(element!=null) {
											
											ExtentManager.reportlog(LogStatus.PASS, "Clicked the Add button", true);
											
										}
											element = driverUtil.waitForElementToBeClickable(By.xpath(PolicyGetButton));
											element.click();
											Thread.sleep(5000);
											
											element = driverUtil.waitForElementToBeAppear(By.xpath(DivisionButton));
											
											if(element!=null) {
												
												ExtentManager.reportlog(LogStatus.PASS, "Policy Detail Displayed successfully", true);
												
											}
											
									
											element = driverUtil.getWebElement(By.xpath(AMSBenefit));
											if (!element.isEnabled()); {
												ExtentManager.reportlog(LogStatus.PASS, "AMS Button is not enabled", true);
											}
											
											
											// Narrative Button 
											
											element =driverUtil.getWebElement(By.xpath(NarrativeButton));
											element.click();
											element =driverUtil.getWebElement(By.xpath(NarrativeButton));
											ExtentManager.reportlog(LogStatus.PASS, "Narrative Button Clicked", true);
											driverUtil.switchToNextTab();
									
											Robot robot= new Robot();
											robot.keyPress(KeyEvent.VK_ENTER);
											Thread.sleep(2000);
											driverUtil.switchToNextTab();
											
											// Bulletin Button
											
											element =driverUtil.getWebElement(By.xpath(Bulletin));
											element.click();
											//driverUtil.switchToNextTab();
											Thread.sleep(2000);
											ExtentManager.reportlog(LogStatus.PASS, "Bulletin Button Clicked", true);
											element =driverUtil.getWebElement(By.xpath(CloseButton));
											element.click();
											
											// Mail Arrangement Button
											//driverUtil.switchToNextTab();
											element =driverUtil.getWebElement(By.xpath(MailArrangement));
											element.click();
											//driverUtil.switchToNextTab();
											Thread.sleep(2000);
											ExtentManager.reportlog(LogStatus.PASS, "Mail Arrangement Button Clicked", true);
											element =driverUtil.getWebElement(By.xpath(CloseButton));
											element.click();
											
											// Claim Response Button 
										
											element =driverUtil.getWebElement(By.xpath(ClaimRespButton));
											element.click();
											//driverUtil.switchToNextTab();
											Thread.sleep(2000);
											ExtentManager.reportlog(LogStatus.PASS, "Claim Response Button Button Clicked", true);
						
											robot.keyPress(KeyEvent.VK_ENTER);
											Thread.sleep(4000);						
																									
											// Cov tax Button
											
											element =driverUtil.getWebElement(By.xpath(CovTaxButton));
											element.click();
											//driverUtil.switchToNextTab();
											Thread.sleep(2000);
											ExtentManager.reportlog(LogStatus.PASS, "Coverage Button Clicked", true);
											element =driverUtil.getWebElement(By.xpath(CloseButton));
											element.click();
											//driverUtil.switchToNextTab();
											
											// Division Button 
											
											element =driverUtil.getWebElement(By.xpath(DivisionButton));
											element.click();
											//driverUtil.switchToNextTab();
											Thread.sleep(2000);
											ExtentManager.reportlog(LogStatus.PASS, "Division Button Clicked", true);
											element =driverUtil.getWebElement(By.xpath(CloseButton));
											element.click();
											//driverUtil.switchToNextTab();
											// CLass Button
											
											element =driverUtil.getWebElement(By.xpath(ClassButton));
											element.click();
											//driverUtil.switchToNextTab();
											Thread.sleep(2000);
											ExtentManager.reportlog(LogStatus.PASS, "Class Button Clicked", true);
											element =driverUtil.getWebElement(By.xpath(CloseButton));
											element.click();
											
											// STD Benefit
											
											element =driverUtil.getWebElement(By.xpath(STDBenefit));
											element.click();
											//driverUtil.switchToNextTab();
											Thread.sleep(2000);
											ExtentManager.reportlog(LogStatus.PASS, "STD Benefit Button Clicked", true);
											element =driverUtil.getWebElement(By.xpath(CloseButton));
											element.click();
											//driverUtil.switchToNextTab();
											
																		
											
											
								};
								
								public void ClickOnPolicySearchButtonTC07(Map<String,String> data) throws Exception{
									Thread.sleep(3000);
									System.out.println("Now in Policy Serach");
									element = driverUtil.waitForElementToBeClickable(By.xpath(PolicySearchButton));
									element.click();
									ExtentManager.reportlog(LogStatus.PASS, "Clicked the Policy search button successfully", true);
									Thread.sleep(5000);
									String AlertMsgActual= driverUtil.getAlertText();
									System.out.println(AlertMsgActual);
									driverUtil.alertAccept();
									String ExpectedAlertMsg="The search criteria entered returned too many records. Please refine your search by completing more fields and try again. (R-6466)";
									
										if 	(AlertMsgActual .equalsIgnoreCase(ExpectedAlertMsg)) {
										ExtentManager.reportlog(LogStatus.PASS, "Validated the popup message successfully", true);
										}
										
										element = driverUtil.waitForElementToBeClickable(By.xpath(TxtPolicyNumber));
										String policyNumber = data.get("PolicyNumber");
										element.sendKeys(policyNumber);; 
										element = driverUtil.waitForElementToBeClickable(By.xpath(PolicySearchButton));
										element.click();
										Thread.sleep(5000);
											
										
										
												element = driverUtil.waitForElementToBeAppear(By.xpath(PolicyGrid));
												
												if(element!=null) {
													
													ExtentManager.reportlog(LogStatus.PASS, "Clicked the Add button", true);
													
												}
													element = driverUtil.waitForElementToBeClickable(By.xpath(PolicyGetButton));
													element.click();
													Thread.sleep(5000);
													
													element = driverUtil.waitForElementToBeAppear(By.xpath(DivisionButton));
													
													if(element!=null) {
														
														ExtentManager.reportlog(LogStatus.PASS, "Policy Detail Displayed successfully", true);
														
													}
													
											
													element = driverUtil.getWebElement(By.xpath(AMSBenefit));
													if (!element.isEnabled()); {
														ExtentManager.reportlog(LogStatus.PASS, "AMS Button is not enabled", true);
													}
																																				
													
													// Division Button 
													
													element =driverUtil.getWebElement(By.xpath(DivisionButton));
													element.click();
													Thread.sleep(2000);
													Robot robot= new Robot();
													robot.keyPress(KeyEvent.VK_ENTER);
													Thread.sleep(2000);
													//driverUtil.switchToNextTab();
													element =driverUtil.getWebElement(By.xpath(DivisionNarrativeButton));
													element.click();
													ExtentManager.reportlog(LogStatus.PASS, "Narrative Button Clicked", true);
													Thread.sleep(2000);
													driverUtil.switchToNextTab();

													robot.keyPress(KeyEvent.VK_ENTER);
													Thread.sleep(2000);
													robot.keyPress(KeyEvent.VK_TAB);

													Thread.sleep(2000);
													robot.keyPress(KeyEvent.VK_ENTER);
													Thread.sleep(2000);

													robot.keyPress(KeyEvent.VK_TAB);
													Thread.sleep(2000);
													robot.keyPress(KeyEvent.VK_ENTER);
													element =driverUtil.getWebElement(By.xpath(NxtDiv));
													element.click();
													Thread.sleep(2000);
													element =driverUtil.getWebElement(By.xpath(PreDiv));
													element.click();
													Thread.sleep(2000);				
																			
													
													
										};
										
										public void ClickOnPolicySearchButtonTC08(Map<String,String> data) throws Exception{
											Thread.sleep(3000);
											System.out.println("Now in Policy Serach");
											element = driverUtil.waitForElementToBeClickable(By.xpath(PolicySearchButton));
											element.click();
											ExtentManager.reportlog(LogStatus.PASS, "Clicked the Policy search button successfully", true);
											Thread.sleep(5000);
											String AlertMsgActual= driverUtil.getAlertText();
											System.out.println(AlertMsgActual);
											driverUtil.alertAccept();
											String ExpectedAlertMsg="The search criteria entered returned too many records. Please refine your search by completing more fields and try again. (R-6466)";
											
												if 	(AlertMsgActual .equalsIgnoreCase(ExpectedAlertMsg)) {
												ExtentManager.reportlog(LogStatus.PASS, "Validated the popup message successfully", true);
												}
												
												element = driverUtil.waitForElementToBeClickable(By.xpath(TxtPolicyNumber));
												String policyNumber = data.get("PolicyNumber");
												element.sendKeys(policyNumber);; 
												element = driverUtil.waitForElementToBeClickable(By.xpath(PolicySearchButton));
												element.click();
												Thread.sleep(5000);
													
												
												
														element = driverUtil.waitForElementToBeAppear(By.xpath(PolicyGrid));
														
														if(element!=null) {
															
															ExtentManager.reportlog(LogStatus.PASS, "Clicked the Add button", true);
															
														}
															element = driverUtil.waitForElementToBeClickable(By.xpath(PolicyGetButton));
															element.click();
															Thread.sleep(5000);
															
															element = driverUtil.waitForElementToBeAppear(By.xpath(DivisionButton));
															
															if(element!=null) {
																
																ExtentManager.reportlog(LogStatus.PASS, "Policy Detail Displayed successfully", true);
																
															}
															
													
															element = driverUtil.getWebElement(By.xpath(AMSBenefit));
															if (!element.isEnabled()); {
																ExtentManager.reportlog(LogStatus.PASS, "AMS Button is not enabled", true);
															}
																																						
															
															// Mail Arrangement Button 
															
															element =driverUtil.getWebElement(By.xpath(MailArrangement));
															element.click();
															//driverUtil.switchToNextTab();

															Thread.sleep(2000);
															ExtentManager.reportlog(LogStatus.PASS, "Mail Arrangement Button Clicked", true);
															element =driverUtil.getWebElement(By.xpath(btnGetMailArrDet));
															element.click();
															Thread.sleep(2000);
															//driverUtil.switchToNextTab();
															element =driverUtil.getWebElement(By.xpath(btnNextMail));
															element.click();
															Thread.sleep(2000);
															element =driverUtil.getWebElement(By.xpath(btnPrevMail));
															element.click();
																								
															element =driverUtil.getWebElement(By.xpath(btnCloseMail));
															element.click();
																												
															
															
												};
												
												public void ClickOnPolicySearchButtonTC09(Map<String,String> data) throws Exception{
													Thread.sleep(3000);
													System.out.println("Now in Policy Serach");
													element = driverUtil.waitForElementToBeClickable(By.xpath(PolicySearchButton));
													element.click();
													ExtentManager.reportlog(LogStatus.PASS, "Clicked the Policy search button successfully", true);
													Thread.sleep(5000);
													String AlertMsgActual= driverUtil.getAlertText();
													System.out.println(AlertMsgActual);
													driverUtil.alertAccept();
													String ExpectedAlertMsg="The search criteria entered returned too many records. Please refine your search by completing more fields and try again. (R-6466)";
													
														if 	(AlertMsgActual .equalsIgnoreCase(ExpectedAlertMsg)) {
														ExtentManager.reportlog(LogStatus.PASS, "Validated the popup message successfully", true);
														}
														
														element = driverUtil.waitForElementToBeClickable(By.xpath(TxtPolicyNumber));
														String policyNumber = data.get("PolicyNumber");
														element.sendKeys(policyNumber);; 
														element = driverUtil.waitForElementToBeClickable(By.xpath(PolicySearchButton));
														element.click();
														Thread.sleep(5000);
															
														
														
																element = driverUtil.waitForElementToBeAppear(By.xpath(PolicyGrid));
																
																if(element!=null) {
																	
																	ExtentManager.reportlog(LogStatus.PASS, "Clicked the Add button", true);
																	
																}
																	element = driverUtil.waitForElementToBeClickable(By.xpath(PolicyGetButton));
																	element.click();
																	Thread.sleep(5000);
																	
																	element = driverUtil.waitForElementToBeAppear(By.xpath(DivisionButton));
																	
																	if(element!=null) {
																		
																		ExtentManager.reportlog(LogStatus.PASS, "Policy Detail Displayed successfully", true);
																		
																	}
																	
															
																	element = driverUtil.getWebElement(By.xpath(AMSBenefit));
																	if (!element.isEnabled()); {
																		ExtentManager.reportlog(LogStatus.PASS, "AMS Button is not enabled", true);
																	}
																																								
																	
																	//Class Button 
																	
																	element =driverUtil.getWebElement(By.xpath(ClassButton));
																	element.click();
																	//driverUtil.switchToNextTab();

																	Thread.sleep(2000);
																	ExtentManager.reportlog(LogStatus.PASS, "Class Button Clicked", true);
																	element =driverUtil.getWebElement(By.xpath(btnGetClass));
																	element.click();
																	Thread.sleep(2000);
																	//driverUtil.switchToNextTab();
																	element =driverUtil.getWebElement(By.xpath(EarlierButton));
																	element.click();
																	Thread.sleep(2000);
																	element =driverUtil.getWebElement(By.xpath(LaterButton));
																	element.click();															
																	element =driverUtil.getWebElement(By.xpath(btnCloseMail));
																	element.click();
																	
																														
																
																	
														};
														
														public void ClickOnPolicySearchButtonTC10(Map<String,String> data) throws Exception{
															Thread.sleep(3000);
															System.out.println("Now in Policy Serach");
															element = driverUtil.waitForElementToBeClickable(By.xpath(PolicySearchButton));
															element.click();
															ExtentManager.reportlog(LogStatus.PASS, "Clicked the Policy search button successfully", true);
															Thread.sleep(5000);
															String AlertMsgActual= driverUtil.getAlertText();
															System.out.println(AlertMsgActual);
															driverUtil.alertAccept();
															String ExpectedAlertMsg="The search criteria entered returned too many records. Please refine your search by completing more fields and try again. (R-6466)";
															
																if 	(AlertMsgActual .equalsIgnoreCase(ExpectedAlertMsg)) {
																ExtentManager.reportlog(LogStatus.PASS, "Validated the popup message successfully", true);
																}
																
																element = driverUtil.waitForElementToBeClickable(By.xpath(TxtPolicyNumber));
																String policyNumber = data.get("PolicyNumber");
																element.sendKeys(policyNumber);; 
																element = driverUtil.waitForElementToBeClickable(By.xpath(PolicySearchButton));
																element.click();
																Thread.sleep(5000);
																	
																
																
																		element = driverUtil.waitForElementToBeAppear(By.xpath(PolicyGrid));
																		
																		if(element!=null) {
																			
																			ExtentManager.reportlog(LogStatus.PASS, "Clicked the Add button", true);
																			
																		}
																			element = driverUtil.waitForElementToBeClickable(By.xpath(PolicyGetButton));
																			element.click();
																			Thread.sleep(5000);
																			
																			element = driverUtil.waitForElementToBeAppear(By.xpath(DivisionButton));
																			
																			if(element!=null) {
																				
																				ExtentManager.reportlog(LogStatus.PASS, "Policy Detail Displayed successfully", true);
																				
																			}
																			
																	
																			element = driverUtil.getWebElement(By.xpath(AMSBenefit));
																			if (!element.isEnabled()); {
																				ExtentManager.reportlog(LogStatus.PASS, "AMS Button is not enabled", true);
																			}
																																										
																			
																			// Claim Response Button 
																			
																			element =driverUtil.getWebElement(By.xpath(ClaimRespButton));
																			element.click();
																			//driverUtil.switchToNextTab();
																			Thread.sleep(2000);
																			ExtentManager.reportlog(LogStatus.PASS, "Claim Response Button Button Clicked", true);
																			
																			Robot robot= new Robot();
																			robot.keyPress(KeyEvent.VK_ENTER);
																			Thread.sleep(4000);	
																																		
																																					
																			// STD Benefit
																			
																			element =driverUtil.getWebElement(By.xpath(STDBenefit));
																			element.click();
																			//driverUtil.switchToNextTab();
																			Thread.sleep(2000);
																			ExtentManager.reportlog(LogStatus.PASS, "STD Benefit Button Clicked", true);
																			
																			element =driverUtil.waitForElementToBeClickable(By.xpath(GetSTDButton));
																			element.click();
																			Thread.sleep(2000);
																			ExtentManager.reportlog(LogStatus.PASS, "STD Benefit detail pop up screen must be displayed along with Narrative,Earlier,Later,Previous Class,Next Class, Offset details and Close buttons and also along with the following tabs :Coverage,Entitlement,Offset and deduction and underwriting", true);
																			
																			element =driverUtil.waitForElementToBeClickable(By.xpath(EntitlementTab));
																			element.click();
																			ExtentManager.reportlog(LogStatus.PASS, "Entitlement Button Clicked Sucessfully.", true);
																			
																			element =driverUtil.waitForElementToBeClickable(By.xpath(OffsetTab));
																			element.click();
																			ExtentManager.reportlog(LogStatus.PASS, "Offset Button Clicked Sucessfully.", true);

																																					
																			element =driverUtil.waitForElementToBeClickable(By.xpath(UnderWritingTab));
																			element.click();
																			ExtentManager.reportlog(LogStatus.PASS, "Underwriting Button Clicked Successfully.", true);
																			
																			element =driverUtil.waitForElementToBeClickable(By.xpath(EarlierButton));
																			element.click();
																			ExtentManager.reportlog(LogStatus.PASS, "Earlier Button Clicked Successfully.", true);
																			
																			element =driverUtil.waitForElementToBeClickable(By.xpath(LaterButton));
																			element.click();
																			ExtentManager.reportlog(LogStatus.PASS, "Later Button Clicked Successfully.", true);
																			
																			element =driverUtil.waitForElementToBeClickable(By.xpath(NxtDiv1));
																			element.click();
																			ExtentManager.reportlog(LogStatus.PASS, "Next Clicked Successfully.", true);
																			
																			element =driverUtil.waitForElementToBeClickable(By.xpath(PreDiv1));
																			element.click();
																			ExtentManager.reportlog(LogStatus.PASS, "Previous Clicked Successfully.", true);
																			
																			element =driverUtil.getWebElement(By.xpath(Narrative));
																			element.click();
																			ExtentManager.reportlog(LogStatus.PASS, "Narrative Button Clicked Successfully.", true);
																																				
																			//Robot robot= new Robot();
																			robot.keyPress(KeyEvent.VK_ENTER);
																			Thread.sleep(4000);
																			
																			element =driverUtil.getWebElement(By.xpath(ButtonCloseDetails));
																			element.click();
																			
																};
				 
																public void ClickOnPolicySearchButtonTC12(Map<String,String> data) throws Exception{
																	Thread.sleep(3000);
																	System.out.println("Now in Policy Serach");
																	element = driverUtil.waitForElementToBeClickable(By.xpath(PolicySearchButton));
																	element.click();
																	ExtentManager.reportlog(LogStatus.PASS, "Clicked the Policy search button successfully", true);
																	Thread.sleep(5000);
																	String AlertMsgActual= driverUtil.getAlertText();
																	System.out.println(AlertMsgActual);
																	driverUtil.alertAccept();
																	String ExpectedAlertMsg="The search criteria entered returned too many records. Please refine your search by completing more fields and try again. (R-6466)";
																	
																		if 	(AlertMsgActual .equalsIgnoreCase(ExpectedAlertMsg)) {
																		ExtentManager.reportlog(LogStatus.PASS, "Validated the popup message successfully", true);
																		}
																		
																		element = driverUtil.waitForElementToBeClickable(By.xpath(TxtPolicyNumber));
																		String policyNumber = data.get("PolicyNumber");
																		element.sendKeys(policyNumber);; 
																		element = driverUtil.waitForElementToBeClickable(By.xpath(PolicySearchButton));
																		element.click();
																		Thread.sleep(5000);
																			
																		
																		
																				element = driverUtil.waitForElementToBeAppear(By.xpath(PolicyGrid));
																				
																				if(element!=null) {
																					
																					ExtentManager.reportlog(LogStatus.PASS, "Clicked the Add button", true);
																					
																				}
																					element = driverUtil.waitForElementToBeClickable(By.xpath(PolicyGetButton));
																					element.click();
																					Thread.sleep(5000);
																					
																					element = driverUtil.waitForElementToBeAppear(By.xpath(DivisionButton));
																					
																					if(element!=null) {
																						
																						ExtentManager.reportlog(LogStatus.PASS, "Policy Detail Displayed successfully", true);
																						
																					}
																					
																			
																					element = driverUtil.getWebElement(By.xpath(AMSBenefit));
																					if (!element.isEnabled()); {
																						ExtentManager.reportlog(LogStatus.PASS, "AMS Button is not enabled", true);
																					}
																																										
																										
																																							
																					// LTD Benefit
																					
																					element =driverUtil.getWebElement(By.xpath(LTDBenefit));
																					element.click();
																					//driverUtil.switchToNextTab();
																					Thread.sleep(2000);
																					ExtentManager.reportlog(LogStatus.PASS, "LTD Benefit Button Clicked", true);
																					
																					element =driverUtil.waitForElementToBeClickable(By.xpath(GetLTDButton));
																					element.click();
																					Thread.sleep(2000);
																					ExtentManager.reportlog(LogStatus.PASS, "LTD Benefit detail pop up screen must be displayed along with Narrative,Earlier,Later,Previous Class,Next Class, Offset details and Close buttons and also along with the following tabs :Coverage,Entitlement,Offset and deduction and underwriting", true);
																																								
																					
																					
																					element =driverUtil.waitForElementToBeClickable(By.xpath(Entitlement));
																					element.click();
																					ExtentManager.reportlog(LogStatus.PASS, "Entitlement Button Clicked Sucessfully.", true);
																					
																					element =driverUtil.waitForElementToBeClickable(By.xpath(Offsets));
																					element.click();
																					ExtentManager.reportlog(LogStatus.PASS, "Offset Button Clicked Sucessfully.", true);
																					
																					element =driverUtil.waitForElementToBeClickable(By.xpath(COLA));
																					element.click();
																					ExtentManager.reportlog(LogStatus.PASS, "COLA Clicked Successfully.", true);
																					
																					element =driverUtil.waitForElementToBeClickable(By.xpath(Pension));
																					element.click();
																					ExtentManager.reportlog(LogStatus.PASS, "Pension Clicked Successfully.", true);
																																							
																					element =driverUtil.waitForElementToBeClickable(By.xpath(Underwriting));
																					element.click();
																					ExtentManager.reportlog(LogStatus.PASS, "Underwriting Button Clicked Successfully.", true);
																					
																																										
																					element =driverUtil.getWebElement(By.xpath(UnderWritingButtonNarrative1));
																					element.click();
																					ExtentManager.reportlog(LogStatus.PASS, "Narrative Button Clicked Successfully.", true);
																					
																					Robot robot= new Robot();
																					robot.keyPress(KeyEvent.VK_ENTER);
																					Thread.sleep(4000);
																					
																					element =driverUtil.getWebElement(By.xpath(UnderWritingButtonNEarlier));
																					element.click();
																					ExtentManager.reportlog(LogStatus.PASS, "Narrative Button Clicked Successfully.", true);
																					
																					element =driverUtil.getWebElement(By.xpath(UnderWritingButtonNLater));
																					element.click();
																					ExtentManager.reportlog(LogStatus.PASS, "Narrative Button Clicked Successfully.", true);
																					
																					element =driverUtil.getWebElement(By.xpath(UnderWritingButtonNext));
																					element.click();
																					ExtentManager.reportlog(LogStatus.PASS, "Narrative Button Clicked Successfully.", true);
																					
																					element =driverUtil.getWebElement(By.xpath(UnderWritingButtonPrev));
																					element.click();
																					ExtentManager.reportlog(LogStatus.PASS, "Previous button Clicked Successfully.", true);
																					
																																									
																					element =driverUtil.getWebElement(By.xpath(ButtonCloseDetails));
																					element.click();
																					
																		};												
																		
																		public void ClickOnPolicySearchButtonTC13(Map<String,String> data) throws Exception{
																			Thread.sleep(3000);
																			System.out.println("Now in Policy Serach");
																			element = driverUtil.waitForElementToBeClickable(By.xpath(PolicySearchButton));
																			element.click();
																			ExtentManager.reportlog(LogStatus.PASS, "Clicked the Policy search button successfully", true);
																			Thread.sleep(5000);
																			String AlertMsgActual= driverUtil.getAlertText();
																			System.out.println(AlertMsgActual);
																			driverUtil.alertAccept();
																			String ExpectedAlertMsg="The search criteria entered returned too many records. Please refine your search by completing more fields and try again. (R-6466)";
																			
																				if 	(AlertMsgActual .equalsIgnoreCase(ExpectedAlertMsg)) {
																				ExtentManager.reportlog(LogStatus.PASS, "Validated the popup message successfully", true);
																				}
																				
																				element = driverUtil.waitForElementToBeClickable(By.xpath(TxtPolicyNumber));
																				String policyNumber = data.get("PolicyNumber");
																				element.sendKeys(policyNumber);; 
																				element = driverUtil.waitForElementToBeClickable(By.xpath(PolicySearchButton));
																				element.click();
																				Thread.sleep(5000);
																					
																				
																				
																						element = driverUtil.waitForElementToBeAppear(By.xpath(PolicyGrid));
																						
																						if(element!=null) {
																							
																							ExtentManager.reportlog(LogStatus.PASS, "Clicked the Add button", true);
																							
																						}
																							element = driverUtil.waitForElementToBeClickable(By.xpath(PolicyGetButton));
																							element.click();
																							Thread.sleep(5000);
																							
																							element = driverUtil.waitForElementToBeAppear(By.xpath(DivisionButton));
																							
																							if(element!=null) {
																								
																								ExtentManager.reportlog(LogStatus.PASS, "Policy Detail Displayed successfully", true);
																								
																							}
																							
																																																
																										
																																									
																							// AMS Benefit Details
																							element = driverUtil.getWebElement(By.xpath(AMSBenefit));
																							element.click();					
																							
																							element = driverUtil.getWebElement(By.xpath(GetBenefit));
																							element.click();
																							
																							element =driverUtil.waitForElementToBeClickable(By.xpath(NarrativeButton));
																							element.click();
																							ExtentManager.reportlog(LogStatus.PASS, "Narrative Button Clicked Sucessfully.", true);
																							
																							Robot robot= new Robot();
																							robot.keyPress(KeyEvent.VK_ENTER);
																							Thread.sleep(4000);
																																														
																							element =driverUtil.waitForElementToBeClickable(By.xpath(EarlierButton));
																							element.click();
																							ExtentManager.reportlog(LogStatus.PASS, "Earlier Button Clicked Sucessfully.", true);
																																																		
																																																						
																																												
																							element =driverUtil.getWebElement(By.xpath(UnderWritingButtonPrev));
																							element.click();
																							ExtentManager.reportlog(LogStatus.PASS, "Previous button Clicked Successfully.", true);
																							
																																											
																							element =driverUtil.getWebElement(By.xpath(ButtonCloseDetails));
																							element.click();
																							
																		};	
																		
																		public void ClickOnPolicySearchButtonTC14(Map<String,String> data) throws Exception{
																			Thread.sleep(3000);
																			System.out.println("Now in Policy Serach");
																			element = driverUtil.waitForElementToBeClickable(By.xpath(PolicySearchButton));
																			element.click();
																			ExtentManager.reportlog(LogStatus.PASS, "Clicked the Policy search button successfully", true);
																			Thread.sleep(5000);
																			String AlertMsgActual= driverUtil.getAlertText();
																			System.out.println(AlertMsgActual);
																			driverUtil.alertAccept();
																			String ExpectedAlertMsg="The search criteria entered returned too many records. Please refine your search by completing more fields and try again. (R-6466)";
																			
																				if 	(AlertMsgActual .equalsIgnoreCase(ExpectedAlertMsg)) {
																				ExtentManager.reportlog(LogStatus.PASS, "Validated the popup message successfully", true);
																				}
																				
																				element = driverUtil.waitForElementToBeClickable(By.xpath(TxtPolicyNumber));
																				String policyNumber = data.get("PolicyNumber");
																				element.sendKeys(policyNumber);; 
																				element = driverUtil.waitForElementToBeClickable(By.xpath(PolicySearchButton));
																				element.click();
																				Thread.sleep(5000);
																					
																				
																				
																						element = driverUtil.waitForElementToBeAppear(By.xpath(PolicyGrid));
																						
																						if(element!=null) {
																							
																							ExtentManager.reportlog(LogStatus.PASS, "Clicked the Add button", true);
																							
																						}
																							element = driverUtil.waitForElementToBeClickable(By.xpath(PolicyGetButton));
																							element.click();
																							Thread.sleep(5000);
																							
																							element = driverUtil.waitForElementToBeAppear(By.xpath(DivisionButton));
																							
																							if(element!=null) {
																								
																								ExtentManager.reportlog(LogStatus.PASS, "Policy Detail Displayed successfully", true);
																								
																							}
																							
																																																
																										
																																									
																							// AMS Benefit Details
																							// Life Benefit 
																							element =driverUtil.getWebElement(By.xpath(LifeBenefit));
																							element.click();
																							//driverUtil.switchToNextTab();
																							Thread.sleep(2000);
																							ExtentManager.reportlog(LogStatus.PASS, "Life Benefit Button Clicked", true);
																							
																							
																							element =driverUtil.waitForElementToBeClickable(By.xpath(GetLifeBenefit));
																							element.click();
																							ExtentManager.reportlog(LogStatus.PASS, "Get Benfit button clicked and record opened Sucessfully.", true);
																							
																							element =driverUtil.waitForElementToBeClickable(By.xpath(Entitlement));
																							element.click();
																							ExtentManager.reportlog(LogStatus.PASS, "Entitlement Link clicked and record opened Sucessfully.", true);
																							
																							element =driverUtil.waitForElementToBeClickable(By.xpath(COLA));
																							element.click();
																							ExtentManager.reportlog(LogStatus.PASS, "Installment Payout clicked and displayed Sucessfully.", true);
																							
																							element =driverUtil.waitForElementToBeClickable(By.xpath(Coverage));
																							element.click();
																							ExtentManager.reportlog(LogStatus.PASS, "Coverage section clicked and displayed Sucessfully.", true);
																							
																																							
																							element =driverUtil.waitForElementToBeClickable(By.xpath(EarlierButton));
																							element.click();
																							ExtentManager.reportlog(LogStatus.PASS, "Earlier Button Clicked Sucessfully.", true);
																																																																													
																																												
																							element =driverUtil.getWebElement(By.xpath(UnderWritingButtonPrev));
																							element.click();
																							ExtentManager.reportlog(LogStatus.PASS, "Previous button Clicked Successfully.", true);
																							
																																											
																							element =driverUtil.getWebElement(By.xpath(ButtonCloseDetails));
																							element.click();
																							
																		};
																		
																		public void ClickOnPolicySearchButtonTC15(Map<String,String> data) throws Exception{
																			Thread.sleep(3000);
																			System.out.println("Now in Policy Serach");
																			element = driverUtil.waitForElementToBeClickable(By.xpath(PolicySearchButton));
																			element.click();
																			ExtentManager.reportlog(LogStatus.PASS, "Clicked the Policy search button successfully", true);
																			Thread.sleep(5000);
																			String AlertMsgActual= driverUtil.getAlertText();
																			System.out.println(AlertMsgActual);
																			driverUtil.alertAccept();
																			String ExpectedAlertMsg="The search criteria entered returned too many records. Please refine your search by completing more fields and try again. (R-6466)";
																			
																				if 	(AlertMsgActual .equalsIgnoreCase(ExpectedAlertMsg)) {
																				ExtentManager.reportlog(LogStatus.PASS, "Validated the popup message successfully", true);
																				}
																				
																				element = driverUtil.waitForElementToBeClickable(By.xpath(TxtPolicyNumber));
																				String policyNumber = data.get("PolicyNumber");
																				element.sendKeys(policyNumber);; 
																				element = driverUtil.waitForElementToBeClickable(By.xpath(PolicySearchButton));
																				element.click();
																				Thread.sleep(5000);
																					
																				
																				
																						element = driverUtil.waitForElementToBeAppear(By.xpath(PolicyGrid));
																						
																						if(element!=null) {
																							
																							ExtentManager.reportlog(LogStatus.PASS, "Clicked the Add button", true);
																							
																						}
																							element = driverUtil.waitForElementToBeClickable(By.xpath(PolicyGetButton));
																							element.click();
																							Thread.sleep(5000);
																							
																							element = driverUtil.waitForElementToBeAppear(By.xpath(DivisionButton));
																							
																							if(element!=null) {
																								
																								ExtentManager.reportlog(LogStatus.PASS, "Policy Detail Displayed successfully", true);
																								
																							}
																							
																																														
																										
																																									
																							// SIB Button
																							
																							element =driverUtil.getWebElement(By.xpath(SIBButton));
																							element.click();
																							//driverUtil.switchToNextTab();
																							Thread.sleep(2000);
																							ExtentManager.reportlog(LogStatus.PASS, "SIB Button Clicked", true);
																							
																							
																							element =driverUtil.waitForElementToBeClickable(By.xpath(GetBenefit));
																							element.click();
																							ExtentManager.reportlog(LogStatus.PASS, "Get Benfit button clicked and record opened Sucessfully.", true);
																							
																							element =driverUtil.waitForElementToBeClickable(By.xpath(Entitlement));
																							element.click();
																							ExtentManager.reportlog(LogStatus.PASS, "Entitlement Link clicked and record opened Sucessfully.", true);
																							
																							element =driverUtil.waitForElementToBeClickable(By.xpath(COLA));
																							element.click();
																							ExtentManager.reportlog(LogStatus.PASS, "Installment Payout clicked and displayed Sucessfully.", true);
																							
																							element =driverUtil.waitForElementToBeClickable(By.xpath(Coverage));
																							element.click();
																							ExtentManager.reportlog(LogStatus.PASS, "Coverage section clicked and displayed Sucessfully.", true);
																							
																																							
																							element =driverUtil.waitForElementToBeClickable(By.xpath(EarlierButton));
																							element.click();
																							ExtentManager.reportlog(LogStatus.PASS, "Earlier Button Clicked Sucessfully.", true);
																																																																													
																																												
																							element =driverUtil.getWebElement(By.xpath(UnderWritingButtonPrev));
																							element.click();
																							ExtentManager.reportlog(LogStatus.PASS, "Previous button Clicked Successfully.", true);
																							
																																											
																							element =driverUtil.getWebElement(By.xpath(ButtonCloseDetails));
																							element.click();
																							
																		};	
																		
																		public void ClickOnPolicySearchButtonTC16(Map<String,String> data) throws Exception{
																			Thread.sleep(3000);
																			System.out.println("Now in Policy Serach");
																			element = driverUtil.waitForElementToBeClickable(By.xpath(PolicySearchButton));
																			element.click();
																			ExtentManager.reportlog(LogStatus.PASS, "Clicked the Policy search button successfully", true);
																			Thread.sleep(5000);
																			String AlertMsgActual= driverUtil.getAlertText();
																			System.out.println(AlertMsgActual);
																			driverUtil.alertAccept();
																			String ExpectedAlertMsg="The search criteria entered returned too many records. Please refine your search by completing more fields and try again. (R-6466)";
																			
																				if 	(AlertMsgActual .equalsIgnoreCase(ExpectedAlertMsg)) {
																				ExtentManager.reportlog(LogStatus.PASS, "Validated the popup message successfully", true);
																				}
																				
																				element = driverUtil.waitForElementToBeClickable(By.xpath(TxtPolicyNumber));
																				String policyNumber = data.get("PolicyNumber");
																				element.sendKeys(policyNumber);; 
																				element = driverUtil.waitForElementToBeClickable(By.xpath(PolicySearchButton));
																				element.click();
																				Thread.sleep(5000);
																					
																				
																				
																						element = driverUtil.waitForElementToBeAppear(By.xpath(PolicyGrid));
																						
																						if(element!=null) {
																							
																							ExtentManager.reportlog(LogStatus.PASS, "Clicked the Add button", true);
																							
																						}
																							element = driverUtil.waitForElementToBeClickable(By.xpath(PolicyGetButton));
																							element.click();
																							Thread.sleep(5000);
																							
																							element = driverUtil.waitForElementToBeAppear(By.xpath(DivisionButton));
																							
																							if(element!=null) {
																								
																								ExtentManager.reportlog(LogStatus.PASS, "Policy Detail Displayed successfully", true);
																								
																							}
																																												
																							// Cov tax Button
																							
																							element =driverUtil.getWebElement(By.xpath(CovTaxButton));
																							element.click();
																							driverUtil.switchToNextTab();
																							Thread.sleep(2000);
																							Robot robot= new Robot();
																							ExtentManager.reportlog(LogStatus.PASS, "Coverage Button Clicked", true);
																							robot.keyPress(KeyEvent.VK_ENTER);
																							driverUtil.switchToNextTab();
																							
																		};												
		}
	
		
	
