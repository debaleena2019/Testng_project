package com.manulife.automation.selenium_execution.pages.web;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.manulife.automation.selenium_execution.utils.DriverUtil;

public class ShoppingCartPage {	
	private DriverUtil driverUtil;
	
	private String cartTitleXPath = "//h1[@id='cart_title']";
	private String cartItemDeleteXPath = "//*[@class='cart_quantity_delete']";
	private String cartTextXPath = "//span[contains(@class,'navigation_page')]";
	
	//*[@id="order_step"]/li[1]/span/text()
	
	public ShoppingCartPage(DriverUtil driverUtil) throws Exception{		
		this.driverUtil = driverUtil;		
		this.driverUtil.waitForJQueryToLoad();
	}		
	
	public String verifyShoppingCart() throws Exception{
		this.driverUtil.waitForElementToBeVisible(By.xpath(this.cartTitleXPath));
		return this.driverUtil.getText(By.xpath(this.cartTextXPath));
	}
	
	public void deleteCartItem() throws InterruptedException {
		List<WebElement> currentItems = this.driverUtil.getWebElements(By.xpath(this.cartItemDeleteXPath));
		int itemCount = currentItems.size();
		while(currentItems.size()>0) {
			currentItems.get(0).click();
			this.driverUtil.waitForElementToBeStale(currentItems.get(0));
			List<WebElement> leftItem = this.driverUtil.getWebElements(By.xpath(this.cartItemDeleteXPath));
			while(leftItem.size()==itemCount) {
				this.driverUtil.pause(500);
			}
			currentItems=leftItem;
		}
	}
}