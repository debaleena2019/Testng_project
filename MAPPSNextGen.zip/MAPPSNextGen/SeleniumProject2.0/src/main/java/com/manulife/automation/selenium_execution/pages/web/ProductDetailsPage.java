package com.manulife.automation.selenium_execution.pages.web;

import org.openqa.selenium.By;
import com.manulife.automation.selenium_core.utils.reports.ExtentManager;
import com.manulife.automation.selenium_execution.utils.DriverUtil;
import com.relevantcodes.extentreports.LogStatus;

public class ProductDetailsPage {	
	private DriverUtil driverUtil;
	
	private String productTitleXPath = "//h1[contains(text(),'%%PRODUCT')]";
	private String productQuantityXPath = "//input[@id='quantity_wanted']";
	private String productSizeXPath = "//select[@id='group_1']";
	private String buttonAddToCartXPath = "//button[@name='Submit']";
	private String buttonContinueShoppingXpath = "//span[@title='Continue shopping']";
	private String buttonProceedCheckOutXpath = "//a[@title='Proceed to checkout']";
	
	public ProductDetailsPage(DriverUtil driverUtil) throws Exception{		
		this.driverUtil = driverUtil;		
		this.driverUtil.waitForJQueryToLoad();
	}		
	
	public String verifyProductTitle(String productNameStr) {
		String productXPath = this.productTitleXPath.replaceAll("%%PRODUCT", productNameStr);
		this.driverUtil.waitForElementToBeVisible(By.xpath(productXPath));
		return this.driverUtil.getText(By.xpath(productXPath));
	}
	
	public void addProductQuantity(String quantityStr) {
		this.driverUtil.clear(By.xpath(this.productQuantityXPath));
		this.driverUtil.sendKeys(By.xpath(this.productQuantityXPath), quantityStr);
		ExtentManager.reportlog(LogStatus.PASS, "Set the quantity " + quantityStr, true);
	}
	
	public void selectProductSize(String sizeStr) {
		this.driverUtil.selectDropdownByText(By.xpath(productSizeXPath), sizeStr);
		ExtentManager.reportlog(LogStatus.PASS, "Select the size " + sizeStr, true);
	}
	
	public void addProductToCart() throws Exception {
		this.driverUtil.click(By.xpath(buttonAddToCartXPath));
		ExtentManager.reportlog(LogStatus.PASS, "Product Added Successfully", true);
	}
	
	public AutomationPracticePage continueShopping() throws Exception {
		this.driverUtil.waitForElementToBeVisible(By.xpath(buttonContinueShoppingXpath));
		this.driverUtil.click(By.xpath(buttonContinueShoppingXpath));
		return new AutomationPracticePage(this.driverUtil);
	}
	
	public ShoppingCartPage proceedToCheckOut() throws Exception {
		this.driverUtil.click(By.xpath(buttonProceedCheckOutXpath));
		ExtentManager.reportlog(LogStatus.PASS, "Proceed for checkout", true);
		return new ShoppingCartPage(this.driverUtil);
	}
	
	public void selectAndAddProductWithinCart(String productNameStr,String quantityStr,String sizeStr) throws Exception {
		AutomationPracticePage homePage = new AutomationPracticePage(this.driverUtil);
		//Set SubIteration 1
		homePage.searchProduct(productNameStr);
		
		ProductDetailsPage productPage = homePage.selectProduct(productNameStr);
		String productName = productPage.verifyProductTitle(productNameStr);
		if(productName.equals(productNameStr)) {
			ExtentManager.reportlog(LogStatus.PASS, "Product Page " + productNameStr + "is displayed", true);
		}
		else {
			ExtentManager.reportlog(LogStatus.FAIL, "Product Page " + productNameStr + "is not displayed", true);
		}
		
		productPage.addProductQuantity(quantityStr);
		productPage.selectProductSize(sizeStr);
		productPage.addProductToCart();
	}
	
}