package com.manulife.automation.selenium_execution.common;


public final class MobileTestType {

	public static final String MOBILEWEB = "mobileWeb";
	public static final String MOBILEAPP = "mobileApp";
}