/**
 * 
 */
package com.manulife.automation.selenium_execution.pages.web;
 


import java.awt.AWTException;
import java.awt.List;
import java.awt.Robot;
import java.util.Map;
import java.util.Set;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.manulife.automation.selenium_core.driver.web.DriverThreadManager;
import com.manulife.automation.selenium_core.utils.ImageCompareUtil;
import com.manulife.automation.selenium_core.utils.reports.ExtentManager;
//import com.manulife.automation.selenium_execution.tests.web.Set;
import com.manulife.automation.selenium_execution.utils.DriverUtil;
import com.relevantcodes.extentreports.LogStatus;

public class Admin {	
	private static final String JavascriptExecutor = null;

	private DriverUtil driverUtil;
	
	WebElement element= null;
	
	ImageCompareUtil imageCompare = new ImageCompareUtil();
	
	private String OpenNavigator = "(//*[@title='Open Navigator'])";
	private String UnlockAccount = "(//*[@title='Unlock Account'])";
	private String AdminLink= "(//*[@class='data-module-link'])[5]";
	private String SysAccess="//*[@title='Sys. Access']";
	private String ClaimLocks= "(//*[@title='Claim Locks'])";
	private String TaskAlloc= "(//*[@title='Task Alloc'])";
	private String ClaimResp= "(//*[@title='Claim Resp'])";
	private String AdminTool= "(//*[@title='Tools'])";
	private String PaymentType= "(//*[@title='Payment Type'])";
	private String CloseDate= "(//*[@id='txtClosedDtTime'])";
	private String SaveButton= "(//*[@id='btnSave'])";
	private String BroadcastMsg= "(//*[@id='txtBroadCastMsg'])";
	private String ButtonClose= "(//*[@id='btnClose'])";
	private String DropDown1="//*[@id='ddlSysMode']";
	private String Exitbutton="//*[@title='Exit']";
	private String LoggedHeader = "//*[@id='headerHome']/div[1]/div[2]";
	private String LogOutbutton="//*[@class='logoutHome']";
	private String TableMaintenanceLink= "//*[text()='Table Maint.']"; 
	private String btnClearLock="//*[@id='btnClearLock']";
	private String btnClearLockAll="//*[@id='btnClearAllLock']";
	private String savebutton="//input[@title='Save']";//
	private String closebutton="//*[@id='Close']";
	private String PopUpOkButton="//*[@value='OK']";
	private String AddButtonPayment="//*[@id='addid']";
	private String EnglishPaymentType="//*[@id='PmtDedTypeEnglish']";
	private String FrenchPaymentType="//*[@id='PmtDedTypeFrench']";
	private String Code="//*[@id='Code']";
	private String MaxPaymentAmt="//*[@id='MaxPmtAmt']";
	private String SaveIcon="//*[@class='t-icon t-insert']";
	private String CancelIcon="//*[@class='t-icon t-cancel']";
	private String ExternalContribution="(//*[@id='rdbClaimShow'])[2]";
	private String ClaimEnquiry="(//*[@id='rdbClaimShow'])[3]";
	private String AssociatedPaymentRdbtn="(//*[@id='rdbClaimShow'])[4]";
	private String OtherPaymentRdbtn="(//*[@id='rdbClaimShow'])[5]";
	private String PaymentDeductionRdbtn="(//*[@id='rdbClaimShow'])[6]";
	private String EditIcon="(//*[@id='editid'])[1]";
	private String DeleteIcon="(//*[@id='editid'])[2]";
	private String UpdateIcon="//*[@class='t-icon t-update']";
	private String SearchTask="//*[@id='Search']";
	private String TaskListButton="//*[@id='btnTaskList']";
	private String UserList="//*[@id='hdnUsersHtml']";
	private String TxtPolicNumber="(//*[@id='txtPolicyNumber'])[2]";
	private String BenType="//*[@id='ddlBenType']";
	private String Role="//*[@id='ddlRole']";
	private String ClaimOfice="//*[@id='ddlClaimOffice']";
	private String UserIndent="//*[@id='ddlUserIdent']";
	private String AssignedInd="//*[@id='ddlAssignedInd']";
	private String Comments="//*[@id='txtComment']";
	private String Addbtn="//*[@class='t-button t-button-icontext t-grid-add']";
	private String Editbtn="//*[@class='t-icon t-edit']";
	private String txtToolCode="//*[@id='txtToolCode']";
	private String txtToolName="//*[@id='txtToolName']";
	private String ddlTaskReq="//*[@id='ddlTaskToRequestor']";
	private String ddlTaskProvider="//*[@id='ddlTaskToProvider']";
	private String ddlTaskClaimant="//*[@id='ddlLetterToClaimant']"; 
	private String Chkbox1="//*[@id='chkAppreqd']";
	private String Chkbox2="//*[@id='chkRehab']";
	private String Chkbox3="//*[@id='chkSISIP']";
	private String Chkbox4="//*[@id='chkIntake']";
	private String Chkbox5="//*[@id='chkIntakeReq']";
	private String Chkbox6="//*[@id='chkStdLtdStands']";
	private String Chkbox7="//*[@id='chkActiveFlag']";
	private String ReferalTemplate="//*[@id='txtRefralTmpl']";
	private String Provider="//*[@id='ddlLetterToProvider']";
	private String BenOption="//*[@title='Ben. Options']";
	private String UserProfile="//*[@title='User Profile']";
	private String BeneType="//*[@id='ddlBenType']";
	private String txtMax1="//*[@id='txtMaxAdjPayPayment']"; 
	private String txtMax2="//*[@id='txtMaxAutoPayClm']";
	private String txtMax3="//*[@id='txtMaxAdjPayAdv']";
	private String EFT="//*[@id='txtEFT']";
	private String Cheque="//*[@id='txtCheque']";
	private String SingleAuthLimit="//*[@id='txtSingleAuthLimit']";
	private String SingleChkLimit="//*[@id='txtSingleChequeLimit']";
	private String PaymtFreq="//*[@id='ddlPmtFreq']";
	
	//private DriverUtil driverUtil;
	private WebDriver driver = DriverThreadManager.getDriverStatic();
	
	
	public Admin(DriverUtil driverUtil) throws Exception {
		this.driverUtil = driverUtil;		
		this.driverUtil.waitForJQueryToLoad();
	}
	
	public WebDriver getDriver()
	{
		return DriverThreadManager.getDriverStatic();
	} 
	
	public void ClickOnNavigator(Map<String,String> data) throws Exception{
		
		element = driverUtil.waitForElementToBeClickable(By.xpath(OpenNavigator));
			Thread.sleep(2000);
			driverUtil.click(By.xpath(OpenNavigator));
			WebElement element1= null;
			element1 = driverUtil.waitForElementToBeClickable(By.xpath(UnlockAccount));
			ExtentManager.reportlog(LogStatus.PASS, "Clicked the open navigator button successfully", true);

			JavascriptExecutor JS = (JavascriptExecutor)driver;
			JS.executeScript("arguments[0].click();", element1);
			
			Thread.sleep(2000);
			System.out.println("Exiting from Function 1");
		
	}
	
	public void ClickOnAdmin(Map<String,String> data) throws Exception{
		Thread.sleep(3000);
		System.out.println("Now in Admin Function Function");
		element = driverUtil.getWebElement(By.xpath(AdminLink));
		Thread.sleep(3000);
		
		JavascriptExecutor JS = (JavascriptExecutor)driver;
		JS.executeScript("arguments[0].click();", element);
		
		
		/*try {
		driverUtil.click(By.xpath(AdminLink));
		}catch (Exception e) {
			// TODO: handle exception
			element.sendKeys(Keys.TAB);
			element.sendKeys(Keys.ENTER);
		}*/
			ExtentManager.reportlog(LogStatus.PASS, "Clicked the Utilities successfully", true);
			
		
	}
		
					
			public void ClickonSysAccess(Map<String,String> data) throws Exception {
			
					element = driverUtil.getDriver().findElement(By.xpath(SysAccess));
						if(element!=null) {
						try {
							driverUtil.click(By.xpath(SysAccess));
							}catch (Exception e) {
								// TODO: handle exception
								element.sendKeys(Keys.TAB);
								element.sendKeys(Keys.ENTER);
							}
						ExtentManager.reportlog(LogStatus.PASS, "SysAccess Clicked", true);
						
					}
			}
			
			public void ClaimLocks(Map<String,String> data) throws Exception {
				
				element = driverUtil.getDriver().findElement(By.xpath(ClaimLocks));
					if(element!=null) {
						driverUtil.click(By.xpath(ClaimLocks));
					ExtentManager.reportlog(LogStatus.PASS, "ClaimLocks Clicked", true);
					
				}
		}
			
			public void PaymentType(Map<String,String> data) throws Exception {
				
				element = driverUtil.getDriver().findElement(By.xpath(PaymentType));
					if(element!=null) {
						driverUtil.click(By.xpath(PaymentType));
					ExtentManager.reportlog(LogStatus.PASS, "PaymentType Clicked", true);
					
				}
					Thread.sleep(1000);
					
					String RadioButtonValue= data.get("TC_Number");
					
					switch (RadioButtonValue) {
					
					case "TC60" :
					
						element = driverUtil.getDriver().findElement(By.xpath(ExternalContribution));
					
					break;
					
					case "TC61":
					
					element = driverUtil.getDriver().findElement(By.xpath(AssociatedPaymentRdbtn));
					
					break;
					
					
					case "TC62":
				
						element = driverUtil.getDriver().findElement(By.xpath(OtherPaymentRdbtn));
				
					break;
					
					case "TC63":
						
						element = driverUtil.getDriver().findElement(By.xpath(OtherPaymentRdbtn));
				
					break;
					
					case "TC64":
						
						element = driverUtil.getDriver().findElement(By.xpath(ClaimEnquiry));
				
					break;
				}
					
					element.click();
					
					
					// Saving the data & validating error message
					
					Thread.sleep(1000);
					element = driverUtil.getDriver().findElement(By.xpath(SaveIcon));
					element.click();
					Thread.sleep(2000);
					driverUtil.getAlertText();
					ExtentManager.reportlog(LogStatus.PASS, "Error message validated", true);
					driverUtil.alertAccept();
									
					
					Thread.sleep(1000);
					element = driverUtil.getDriver().findElement(By.xpath(EditIcon));
					element.click();
					
					
					
					// Putting data in Mandatory Fields.
					
					element = driverUtil.getDriver().findElement(By.xpath(EnglishPaymentType));
					element.sendKeys("Test");
					Thread.sleep(1000);
					
					element = driverUtil.getDriver().findElement(By.xpath(FrenchPaymentType));
					element.sendKeys("Test");
					Thread.sleep(1000);
					
					element = driverUtil.getDriver().findElement(By.xpath(MaxPaymentAmt));
					element.sendKeys("1000");
					Thread.sleep(1000);
					
					element = driverUtil.getDriver().findElement(By.xpath(Code));
					element.sendKeys("A100");
					Thread.sleep(1000);
					
					element = driverUtil.getDriver().findElement(By.xpath(CancelIcon));
					element.click();
					Thread.sleep(1000);
					
					driverUtil.getAlertText();
					Thread.sleep(1000);
					driverUtil.alertDismiss();
					Thread.sleep(1000);
					Thread.sleep(1000);
					element = driverUtil.getDriver().findElement(By.xpath(SaveIcon));
					element.click();
					
					// Closing the Admin Screen
					
					Thread.sleep(1000);
					element= driverUtil.getWebElement(By.xpath(ButtonClose));
					element.click();
					
									
					
		}	
			
						//
						
			public void ClickonClosed(Map<String,String> data) throws Exception {	
						String Ele= driverUtil.getSelectedDropdownValue(By.xpath(DropDown1));
						if (Ele.equals("OPEN")) {
							ExtentManager.reportlog(LogStatus.PASS, "SysAccess Clicked", true);	
						}	
						driverUtil.selectDropdownByValue(By.xpath(DropDown1),"CLOSED");
						
						Robot robot= new Robot();
						robot.keyPress(KeyEvent.VK_ENTER);
						Thread.sleep(2000);
						//String UserClosed= driverUtil.getText(By.xpath(ClosedBy));
						String ClosedDate= driverUtil.getText(By.xpath(CloseDate));
						//ExtentManager.reportlog(LogStatus.PASS, "Closed by " + UserClosed+ "ClosedDate : " + ClosedDate, true);	
						
						/*for (WebElement webElement : MyList) {
							String ele = webElement.getText();
						}*/
								 		
				}
			
			public void ClickonSave(Map<String,String> data) throws Exception {	
					element= driverUtil.getWebElement(By.xpath(SaveButton));
					driverUtil.click(By.xpath(SaveButton));
					String ActualMsg=driverUtil.getAlertText();
					driverUtil.alertAccept();
					String ExpectedMsg="Please correct the following fields which cannot be blank or correct the invalid data: (R - 1001)";
					if(ActualMsg.equals(ExpectedMsg)) {
					ExtentManager.reportlog(LogStatus.PASS, "Message Verified", true);	
					}
					System.out.println(ActualMsg);
					element= driverUtil.getWebElement(By.xpath(BroadcastMsg));
					element.sendKeys("Test");
					Thread.sleep(1500);
					element= driverUtil.getWebElement(By.xpath(ButtonClose));
					element.click();
					String ActualMsg1=driverUtil.getAlertText();
					driverUtil.alertDismiss();
					String ExpectedMsg1= "You have not saved your changes. Click OK to continue without saving or Cancel to remain on this page. (R - 1007)";
					if(ActualMsg1.equals(ExpectedMsg1)) {
							ExtentManager.reportlog(LogStatus.PASS, "Message Verified", true);	
						}
					element= driverUtil.getWebElement(By.xpath(SaveButton));
					element.click();
					Thread.sleep(1500);
					element= driverUtil.getWebElement(By.xpath(ButtonClose));
					element.click();
					
					element= driverUtil.getWebElement(By.xpath(Exitbutton));
					element.click();
					Thread.sleep(1500);
					driverUtil.alertAccept();
					System.out.println("Here");
					
					//System.out.println(driverUtil.getWebElement(By.xpath("//*")).getText());
					
					//String lement = driverUtil.getDriver().getTitle();
					//System.out.println(lement);
					element= driverUtil.waitForElementToBeVisible(By.xpath(LoggedHeader));
					//element = element.findElement(By.xpath(LogOutbutton));
					element.click();
					driverUtil.alertAccept();
					
					
					
				}
			
			public void ClaimRelease(Map<String,String> data) throws Exception {
				
				String Ele=data.get("TC_Number");
				if (Ele.equals("TC57")) {
					element= driverUtil.getWebElement(By.xpath(btnClearLock));
					element.click();
				}
				
				else {
					
					element= driverUtil.getWebElement(By.xpath(btnClearLockAll));
					element.click();
				}
				
					
			}
			
			public void PaymentType_Update(Map<String,String> data) throws Exception {
				
				element = driverUtil.getDriver().findElement(By.xpath(PaymentType));
					if(element!=null) {
						driverUtil.click(By.xpath(PaymentType));
					ExtentManager.reportlog(LogStatus.PASS, "PaymentType Clicked", true);
					
				}
					Thread.sleep(1000);
					
					String RadioButtonValue= data.get("TC_Number");
					
					switch (RadioButtonValue) {
										
					// Claim Enquiry Update :	
					
					case "TC66" :
										
					element = driverUtil.getDriver().findElement(By.xpath(ExternalContribution));
					
					break;
					
					// Associated Payment Option :
					
					case "TC67":
					
					element = driverUtil.getDriver().findElement(By.xpath(AssociatedPaymentRdbtn));
					
					break;
					
					//Other Payment Radio					
					
					case "TC68":
								
					element = driverUtil.getDriver().findElement(By.xpath(OtherPaymentRdbtn));
				
					break;
					
					// Payment Deduction Button
					
					case "TC69":
						
					element = driverUtil.getDriver().findElement(By.xpath(PaymentDeductionRdbtn));
				
					break;
					
					
				}
					
					element.click();
					
					// Clicking on the Edit Button
					
					Thread.sleep(1000);
					element = driverUtil.getDriver().findElement(By.xpath(EditIcon));
					element.click();
					
					// Deleting data from Mandatory Fields.
					
					element = driverUtil.getDriver().findElement(By.xpath(EnglishPaymentType));
					element.clear();
					Thread.sleep(1000);
					
					element = driverUtil.getDriver().findElement(By.xpath(FrenchPaymentType));
					element.clear();
					Thread.sleep(1000);
					
									
					element = driverUtil.getDriver().findElement(By.xpath(MaxPaymentAmt));
					element.clear();
					Thread.sleep(1000);										
									
					// Saving the data & validating error message
					
					Thread.sleep(1000);
					element = driverUtil.getDriver().findElement(By.xpath(UpdateIcon));
					element.click();
					Thread.sleep(2000);
					driverUtil.getAlertText();
					ExtentManager.reportlog(LogStatus.PASS, "Error message validated", true);
					driverUtil.alertAccept();
					
					// Entering data into mandatory Field
					element = driverUtil.getDriver().findElement(By.xpath(EnglishPaymentType));
					element.sendKeys("TestTest");
					Thread.sleep(1000);
					
					element = driverUtil.getDriver().findElement(By.xpath(FrenchPaymentType));
					element.sendKeys("AbcTest");
					Thread.sleep(1000);
					
									
					element = driverUtil.getDriver().findElement(By.xpath(MaxPaymentAmt));
					element.sendKeys("1000");
					Thread.sleep(1000);	
					
					element = driverUtil.getDriver().findElement(By.xpath(CancelIcon));
					element.click();
					Thread.sleep(2000);
					driverUtil.getAlertText();
					ExtentManager.reportlog(LogStatus.PASS, "Error message validated", true);
					driverUtil.alertDismiss();
					
					element = driverUtil.getDriver().findElement(By.xpath(SaveIcon));
					element.click();
					Thread.sleep(1000);
					
					
					
					//Clicking on Delete button
					
					Thread.sleep(1000);
					element = driverUtil.getDriver().findElement(By.xpath(DeleteIcon));
					element.click();
					
				
			}

			
			public void TaskAlloc(Map<String,String> data) throws Exception {
				
				
					element= driverUtil.getWebElement(By.xpath(TaskAlloc));
					element.click();
					Thread.sleep(1000);
					
					
					
			}
			
			
			public void TaskAllocSearch(Map<String,String> data) throws Exception {
				
				element= driverUtil.getWebElement(By.xpath(SearchTask));
				element.click();
				Thread.sleep(1000);
				
				element= driverUtil.getWebElement(By.xpath(TaskListButton));
				element.click();
				Thread.sleep(1000);
				System.out.println(driver.getTitle());
				java.util.List<WebElement> MyList= driverUtil.getAllDropdownValues(By.xpath(UserList));
				Thread.sleep(1000);
			
			}
			
				
			public void ClaimResp(Map<String,String> data) throws Exception {
				
				element= driverUtil.getWebElement(By.xpath(ClaimResp));
				element.click();
				Thread.sleep(1000);
			}
			
			public void AdminToolClick(Map<String,String> data) throws Exception {
				
				element= driverUtil.getWebElement(By.xpath(AdminTool));
				element.click();
				Thread.sleep(1000);
			}
			
			public void NewClaimResp(Map<String,String> data) throws Exception {
				
				
				
				element= driverUtil.getWebElement(By.xpath(Addbtn));
				element.click();
				Thread.sleep(1000);
				//switchToNextWindowByTitle4("Insert");;
				
				element= driverUtil.getWebElement(By.xpath(TxtPolicNumber));
				element.sendKeys("0901724");
				Thread.sleep(1000);
				
				driverUtil.selectDropdownByValue(By.xpath(BenType),"AMS");
				Thread.sleep(1000);
				
				driverUtil.selectDropdownByValue(By.xpath(ClaimOfice),"SI - SISIP");
				Thread.sleep(1000);
										
				driverUtil.selectDropdownByValue(By.xpath(Role),"AMSCM - AMS Case Manager");
				Thread.sleep(1000);
				ExtentManager.reportlog(LogStatus.PASS, "Parameters selected", true);		
				
				driverUtil.selectDropdownByValue(By.xpath(AssignedInd),"Y");
				Thread.sleep(1000);
				//element= driverUtil.getWebElement(By.xpath(AssignedInd));
				driverUtil.selectDropdownByValue(By.xpath(UserIndent),"AAHFX");
				Thread.sleep(1000);
				
				element= driverUtil.getWebElement(By.xpath(Comments));
				element.sendKeys("Test");
				
			}

			public void AddingNewToolRecord(Map<String,String> data) throws Exception {
					
				element= driverUtil.getWebElement(By.xpath(Addbtn));
				element.click();
				Thread.sleep(1000);
				
				element= driverUtil.getWebElement(By.xpath(txtToolName));
				element.sendKeys("Automation");
				Thread.sleep(1000);
				
				
				element= driverUtil.getWebElement(By.xpath(txtToolCode));
				element.sendKeys("AX");
				Thread.sleep(1000);
				
				driverUtil.selectDropdownByIndex(By.xpath(ddlTaskReq),1);
				Thread.sleep(1000);
				element.sendKeys(Keys.ENTER);
						
				driverUtil.selectDropdownByIndex(By.xpath(ddlTaskProvider),1);
				Thread.sleep(1000);
				element.sendKeys(Keys.ENTER);
				
				driverUtil.selectDropdownByIndex(By.xpath(Provider),1);
				Thread.sleep(1000);
				element.sendKeys(Keys.ENTER);
				
				driverUtil.selectDropdownByIndex(By.xpath(ddlTaskClaimant),1);
				Thread.sleep(1000);
				element.sendKeys(Keys.ENTER);
				
				element= driverUtil.getWebElement(By.xpath(Chkbox1));
				element.click();
				Thread.sleep(1000);
				
				element= driverUtil.getWebElement(By.xpath(Chkbox2));
				element.click();
				Thread.sleep(1000);
				
				element= driverUtil.getWebElement(By.xpath(Chkbox3));
				element.click();
				Thread.sleep(1000);
				
				element= driverUtil.getWebElement(By.xpath(Chkbox4));
				element.click();
				Thread.sleep(1000);
				
				element= driverUtil.getWebElement(By.xpath(Chkbox5));
				element.click();
				Thread.sleep(1000);
				
				element= driverUtil.getWebElement(By.xpath(Chkbox6));
				element.click();
				Thread.sleep(1000);
				
				element= driverUtil.getWebElement(By.xpath(Chkbox7));
				element.click();
				Thread.sleep(1000);
				
				element= driverUtil.getWebElement(By.xpath(SaveIcon));
				element.click();
				Thread.sleep(1000);
				ExtentManager.reportlog(LogStatus.PASS, "Parameters selected & Record saved", true);
			}
			
			public void ModifygNewToolRecord(Map<String,String> data) throws Exception {
				
				element= driverUtil.getWebElement(By.xpath(Editbtn));
				element.click();
				Thread.sleep(1000);
				
				element= driverUtil.getWebElement(By.xpath(txtToolName));
				element.sendKeys("Automation_Update");
				Thread.sleep(1000);
										
				element= driverUtil.getWebElement(By.xpath(SaveIcon));
				element.click();
				Thread.sleep(1000);
				ExtentManager.reportlog(LogStatus.PASS, "Parameters selected & Record saved", true);
			}
			
			
			public void BeneOption(Map<String,String> data) throws Exception {
				
				element= driverUtil.getWebElement(By.xpath(BenOption));
				element.click();
				Thread.sleep(1000);		
				ExtentManager.reportlog(LogStatus.PASS, "Ben.Option Clicked", true);
			}
			
			
			public void AdminUserProfile(Map<String,String> data) throws Exception {
				
				element= driverUtil.getWebElement(By.xpath(UserProfile));
				element.click();
				Thread.sleep(1000);		
				ExtentManager.reportlog(LogStatus.PASS, "User Profile Clicked", true);
			}
			
			public void BeneValidation(Map<String,String> data) throws Exception {
				
				
				String BeneTyp= data.get("TC_Number");
				
				switch (BeneTyp) {
									
				// Claim Enquiry Update :	
				
				case "TC76" :
						
					driverUtil.selectDropdownByIndex(By.xpath(BeneType),1);
					Thread.sleep(1000);
					element.sendKeys(Keys.ENTER);		
					ExtentManager.reportlog(LogStatus.PASS, "Ben.Option selected", true);
				
				
				break;
				
				case "TC77" :
					
					driverUtil.selectDropdownByIndex(By.xpath(BeneType),2);
					Thread.sleep(1000);
					element.sendKeys(Keys.ENTER);		
					ExtentManager.reportlog(LogStatus.PASS, "Ben.Option selected", true);
				
				
				break;
				
				case "TC78" :
					
					driverUtil.selectDropdownByIndex(By.xpath(BeneType),4);
					Thread.sleep(1000);
					element.sendKeys(Keys.ENTER);		
					ExtentManager.reportlog(LogStatus.PASS, "Ben.Option selected", true);
				
				
				break;
				
				case "TC79" :
					
					driverUtil.selectDropdownByIndex(By.xpath(BeneType),5);
					Thread.sleep(1000);
					element.sendKeys(Keys.ENTER);		
					ExtentManager.reportlog(LogStatus.PASS, "Ben.Option selected", true);
				
				
				break;
				
				
				case "TC80" :
					
					driverUtil.selectDropdownByIndex(By.xpath(BeneType),6);
					Thread.sleep(1000);
					element.sendKeys(Keys.ENTER);		
					ExtentManager.reportlog(LogStatus.PASS, "Ben.Option selected", true);
				
				
				break;
				
				}
				
				element= driverUtil.getWebElement(By.xpath(txtMax1));
				String Expected1=element.getAttribute("value");
				
				element= driverUtil.getWebElement(By.xpath(txtMax2));
				String Expected2=element.getAttribute("value");
				
				element= driverUtil.getWebElement(By.xpath(txtMax3));
				String Expected3=element.getAttribute("value");

				if ((BeneTyp.equals("TC78")) || (BeneTyp.equals("TC76"))) {
					
					if ((Expected1.equals("00Y")) & (Expected2.equals("00Y")) & (Expected3.equals("00Y")))  {
					ExtentManager.reportlog(LogStatus.PASS, "Amount is populated as expected", true);
				    
					}
				}
				
				if (BeneTyp.equals("TC77")) //|| (BeneTyp.equals("TC76"))) {
					
						{	if ((Expected1.equals("24M")) & (Expected2.equals("24M")) & (Expected3.equals("12M")))  {
							
							ExtentManager.reportlog(LogStatus.PASS, "Amount is populated as expected", true);
				    
					}
				}
				
				
				if (BeneTyp.equals("TC79")) //|| (BeneTyp.equals("TC76"))) {
					
					{	if ((Expected1.equals("36M")) & (Expected2.equals("36M")) & (Expected3.equals("01Y")))  {
					
					ExtentManager.reportlog(LogStatus.PASS, "Amount is populated as expected", true);
		    
					}
				}
				
				
				element= driverUtil.getWebElement(By.xpath(EFT));
				String EFT=element.getAttribute("value");
				element= driverUtil.getWebElement(By.xpath(Cheque));
				String Cheque=element.getAttribute("value");
				
				element= driverUtil.getWebElement(By.xpath(SingleAuthLimit));
				String AuthLimit= element.getAttribute("value");	
				element= driverUtil.getWebElement(By.xpath(SingleChkLimit));
				String SingleChkLimit= element.getAttribute("value");
				
				
				switch (BeneTyp) {
				
				// Claim Enquiry Update :	
				
				case "TC76" :
						
					if ((EFT.equals("10D")) & (Cheque.equals("10D")) & (AuthLimit.equals("25000.00")) & (SingleChkLimit.equals("25000.00")) ) {
						ExtentManager.reportlog(LogStatus.PASS, "EFT & Check Amount is : "+EFT, true);
						ExtentManager.reportlog(LogStatus.PASS, "Auth Limit & Single Chk Limit Amount is : "+SingleChkLimit, true);
						}
				
				   break;
				
				
				case "TC77" :
					
					if ((EFT.equals("13D")) & (Cheque.equals("13D")) & (AuthLimit.equals("100000.00")) & (SingleChkLimit.equals("900000.00")) ) {
						ExtentManager.reportlog(LogStatus.PASS, "EFT & Check Amount is : "+EFT, true);
						ExtentManager.reportlog(LogStatus.PASS, "Auth Limit & Single Chk Limit Amount is : "+SingleChkLimit , true);
						}
				
				   break;   
				   
				case "TC78" :
					
					if ((EFT.equals("10D")) & (Cheque.equals("10D")) & (AuthLimit.equals("10000.00")) & (SingleChkLimit.equals("10000.00")) ) {
						ExtentManager.reportlog(LogStatus.PASS, "EFT & Check Amount is : "+EFT, true);
						ExtentManager.reportlog(LogStatus.PASS, "Auth Limit & Single Chk Limit Amount is : "+SingleChkLimit , true);
						}
				
				   break; 
				   
				case "TC79" :
					
					if ((EFT.equals("10D")) & (Cheque.equals("10D")) & (AuthLimit.equals("100000.00")) & (SingleChkLimit.equals("500000.00")) ) {
						ExtentManager.reportlog(LogStatus.PASS, "EFT & Check Amount is : "+EFT, true);
						ExtentManager.reportlog(LogStatus.PASS, "Auth Limit & Single Chk Limit Amount is : "+SingleChkLimit , true);
						}
				
				   break;  
				}
						
				element= driverUtil.getWebElement(By.xpath(ButtonClose));
				element.click();
						
			}
			
			public void BeneValidation1(Map<String,String> data) throws Exception {
				
				String BeneTyp= data.get("TC_Number");
				
				switch (BeneTyp) {
									
				// Claim Enquiry Update :	
				
				case "TC80" :
						
					driverUtil.selectDropdownByIndex(By.xpath(BeneType),5);
					Thread.sleep(1000);
					//element.sendKeys(Keys.ENTER);		
					ExtentManager.reportlog(LogStatus.PASS, "Ben.Option selected", true);
					java.util.List<WebElement> dropdownVals = driverUtil.getAllDropdownValues(By.xpath(PaymtFreq));;
					driverUtil.selectDropdownByIndex(By.xpath(PaymtFreq),1);
					
					element= driverUtil.waitForElementToBeAppear(By.xpath(txtMax1));
					String Expected1=element.getAttribute("value");
					
					element= driverUtil.waitForElementToBeAppear(By.xpath(txtMax2));
					String Expected2=element.getAttribute("value");
					
					element= driverUtil.waitForElementToBeAppear(By.xpath(txtMax3));
					String Expected3=element.getAttribute("value");
					
					element= driverUtil.waitForElementToBeAppear(By.xpath(EFT));
					String strEFT=element.getAttribute("value");
					
					element= driverUtil.waitForElementToBeAppear(By.xpath(Cheque));
					String strCheque=element.getAttribute("value");
					
					element= driverUtil.waitForElementToBeAppear(By.xpath(SingleAuthLimit));
					String AuthLimit= element.getAttribute("value");
					
					element= driverUtil.waitForElementToBeAppear(By.xpath(SingleChkLimit));
					String strSingleChkLimit= element.getAttribute("value");
					
						if ((Expected1.equals("06M")) & (Expected2.equals("12W")) & (Expected3.equals("02M")))  {
						
						ExtentManager.reportlog(LogStatus.PASS, "Amount is populated as expected", true);
			    
						}
						
						if ((strEFT.equals("09D")) & (Cheque.equals("09D")) & (AuthLimit.equals("100000.00")) & (strSingleChkLimit.equals("750000.00")) ) {
							
							ExtentManager.reportlog(LogStatus.PASS, "EFT & Check Amount is : "+EFT, true);
							ExtentManager.reportlog(LogStatus.PASS, "Auth Limit & Single Chk Limit Amount is : "+SingleChkLimit , true);
						}
						
						driverUtil.selectDropdownByIndex(By.xpath(PaymtFreq),2);
						
						element= driverUtil.waitForElementToBeAppear(By.xpath(txtMax1));
						String Expected1a=element.getAttribute("value");
						
						element= driverUtil.waitForElementToBeAppear(By.xpath(txtMax2));
						String Expected2a=element.getAttribute("value");
						
						element= driverUtil.waitForElementToBeAppear(By.xpath(txtMax3));
						String Expected3a=element.getAttribute("value");
						
						element= driverUtil.waitForElementToBeAppear(By.xpath(EFT));
						String EFT1=element.getAttribute("value");
						
						element= driverUtil.waitForElementToBeAppear(By.xpath(Cheque));
						String Cheque1=element.getAttribute("value");
						
						element= driverUtil.waitForElementToBeAppear(By.xpath(SingleAuthLimit));
						String AuthLimit1= element.getAttribute("value");
						
						element= driverUtil.waitForElementToBeAppear(By.xpath(SingleChkLimit));
						String SingleChkLimit1= element.getAttribute("value");
						
							if ((Expected1a.equals("06M")) & (Expected2a.equals("12W")) & (Expected3a.equals("02M")))  {
							
							ExtentManager.reportlog(LogStatus.PASS, "Amount is populated as expected", true);
				    
							}
							
							if ((EFT1.equals("13D")) & (Cheque1.equals("13D")) & (AuthLimit1.equals("100000.00")) & (SingleChkLimit1.equals("750000.00")) ) {
								
								ExtentManager.reportlog(LogStatus.PASS, "EFT & Check Amount is : "+EFT, true);
								ExtentManager.reportlog(LogStatus.PASS, "Auth Limit & Single Chk Limit Amount is : "+SingleChkLimit , true);
							}
							
							driverUtil.selectDropdownByIndex(By.xpath(PaymtFreq),3);
							
							element= driverUtil.waitForElementToBeAppear(By.xpath(txtMax1));
							String Expected1b=element.getAttribute("value");
							
							element= driverUtil.waitForElementToBeAppear(By.xpath(txtMax2));
							String Expected2b=element.getAttribute("value");
							
							element= driverUtil.waitForElementToBeAppear(By.xpath(txtMax3));
							String Expected3b=element.getAttribute("value");
							
							element= driverUtil.waitForElementToBeAppear(By.xpath(EFT));
							String EFT2=element.getAttribute("value");
							
							element= driverUtil.waitForElementToBeAppear(By.xpath(Cheque));
							String Cheque2=element.getAttribute("value");
							
							element= driverUtil.waitForElementToBeAppear(By.xpath(SingleAuthLimit));
							String AuthLimit2= element.getAttribute("value");
							
							element= driverUtil.waitForElementToBeAppear(By.xpath(SingleChkLimit));
							String SingleChkLimit2= element.getAttribute("value");
							
								if ((Expected1b.equals("06M")) & (Expected2b.equals("12W")) & (Expected3b.equals("02M")))  {
								
								ExtentManager.reportlog(LogStatus.PASS, "Amount is populated as expected", true);
					    
								}
								
								if ((EFT2.equals("07D")) & (Cheque2.equals("07D")) & (AuthLimit2.equals("100000.00")) & (SingleChkLimit2.equals("750000.00")) ) {
									
									ExtentManager.reportlog(LogStatus.PASS, "EFT & Check Amount is : "+EFT, true);
									ExtentManager.reportlog(LogStatus.PASS, "Auth Limit & Single Chk Limit Amount is : "+SingleChkLimit , true);
								}
				
							   break;
							   
							   
								case "TC81" :
								
								// LTD Option
									
								driverUtil.selectDropdownByIndex(By.xpath(BeneType),2);
								Thread.sleep(1000);
								//element.sendKeys(Keys.ENTER);		
								ExtentManager.reportlog(LogStatus.PASS, "Ben.Option selected", true);
								java.util.List<WebElement> dropdownVals1 = driverUtil.getAllDropdownValues(By.xpath(PaymtFreq));;
								
								// Payment Freq 2W
								
								driverUtil.selectDropdownByIndex(By.xpath(PaymtFreq),0);
								
								element= driverUtil.waitForElementToBeAppear(By.xpath(txtMax1));
								String Expected1c=element.getAttribute("value");;
								
								element= driverUtil.waitForElementToBeAppear(By.xpath(txtMax2));
								String Expected2c=element.getAttribute("value");;
								
								element= driverUtil.waitForElementToBeAppear(By.xpath(txtMax3));
								String Expected3c=element.getAttribute("value");;
								
								element= driverUtil.waitForElementToBeAppear(By.xpath(EFT));
								String EFT3=element.getAttribute("value");;
								
								element= driverUtil.waitForElementToBeAppear(By.xpath(Cheque));
								String Cheque3=element.getAttribute("value");;
								
								element= driverUtil.waitForElementToBeAppear(By.xpath(SingleAuthLimit));
								String AuthLimit3=element.getAttribute("value");;
								
								element= driverUtil.waitForElementToBeAppear(By.xpath(SingleChkLimit));
								String strSingleChkLimit3= element.getAttribute("value");
								
									if ((Expected1c.equals("24M")) & (Expected2c.equals("14M")) & (Expected3c.equals("12M")))  {
									
									ExtentManager.reportlog(LogStatus.PASS, "Amount is populated as expected", true);
						    
									}
									
									if ((EFT3.equals("09D")) & (Cheque3.equals("09D")) & (AuthLimit3.equals("100000.00")) & (strSingleChkLimit3.equals("750000.00")) ) {
										
										ExtentManager.reportlog(LogStatus.PASS, "EFT & Check Amount is : "+EFT, true);
										ExtentManager.reportlog(LogStatus.PASS, "Auth Limit & Single Chk Limit Amount is : "+SingleChkLimit , true);
									}
									
									// Paymt Freq MN
									
									driverUtil.selectDropdownByIndex(By.xpath(PaymtFreq),1);
									
									element= driverUtil.waitForElementToBeAppear(By.xpath(txtMax1));
									String Expected4c= element.getAttribute("value");
									
									element= driverUtil.waitForElementToBeAppear(By.xpath(txtMax2));
									String Expected4a=element.getAttribute("value");
									
									element= driverUtil.waitForElementToBeAppear(By.xpath(txtMax3));
									String Expected4d=element.getAttribute("value");
									
									element= driverUtil.waitForElementToBeAppear(By.xpath(EFT));
									String EFT4=element.getAttribute("value");
									
									element= driverUtil.waitForElementToBeAppear(By.xpath(Cheque));
									String Cheque4=element.getAttribute("value");
									
									element= driverUtil.waitForElementToBeAppear(By.xpath(SingleAuthLimit));
									String AuthLimit4= element.getAttribute("value");
									
									element= driverUtil.waitForElementToBeAppear(By.xpath(SingleChkLimit));
									String strSingleChkLimit4= element.getAttribute("value");
									
										if ((Expected4c.equals("24M")) & (Expected4a.equals("14M")) & (Expected4d.equals("12M")))  {
										
										ExtentManager.reportlog(LogStatus.PASS, "Amount is populated as expected", true);
							    
										}
										
										if ((EFT4.equals("11D")) & (Cheque4.equals("11D")) & (AuthLimit4.equals("100000.00")) & (strSingleChkLimit4.equals("750000.00")) ) {
											
											ExtentManager.reportlog(LogStatus.PASS, "EFT & Check Amount is : "+EFT, true);
											ExtentManager.reportlog(LogStatus.PASS, "Auth Limit & Single Chk Limit Amount is : "+SingleChkLimit , true);
										}
										
										
										// Paymt Freq MS
										
										driverUtil.selectDropdownByIndex(By.xpath(PaymtFreq),3);
										
										element= driverUtil.waitForElementToBeAppear(By.xpath(txtMax1));
										String Expected5c=element.getAttribute("value");
										
										element= driverUtil.waitForElementToBeAppear(By.xpath(txtMax2));
										String Expected5a=element.getAttribute("value");
										
										element= driverUtil.waitForElementToBeAppear(By.xpath(txtMax3));
										String Expected5d=element.getAttribute("value");
										
										element= driverUtil.waitForElementToBeAppear(By.xpath(EFT));
										String EFT5=element.getText();
										
										element= driverUtil.waitForElementToBeAppear(By.xpath(Cheque));
										String Cheque5=element.getAttribute("value");
										
										element= driverUtil.waitForElementToBeAppear(By.xpath(SingleAuthLimit));
										String AuthLimit5=element.getAttribute("value");
										
										element= driverUtil.waitForElementToBeAppear(By.xpath(SingleChkLimit));
										String strSingleChkLimit5= element.getAttribute("value");
										
											if ((Expected5c.equals("24M")) & (Expected5a.equals("14M")) & (Expected5d.equals("12M")))  {
											
											ExtentManager.reportlog(LogStatus.PASS, "Amount is populated as expected", true);
								    
											}
											
											if ((EFT5.equals("12D")) & (Cheque5.equals("12D")) & (AuthLimit5.equals("100000.00")) & (strSingleChkLimit5.equals("750000.00")) ) {
												
												ExtentManager.reportlog(LogStatus.PASS, "EFT & Check Amount is : "+EFT, true);
												ExtentManager.reportlog(LogStatus.PASS, "Auth Limit & Single Chk Limit Amount is : "+SingleChkLimit , true);
											}
										
											// Paymt Freq SM
											
											driverUtil.selectDropdownByIndex(By.xpath(PaymtFreq),4);
											
											element= driverUtil.waitForElementToBeAppear(By.xpath(txtMax1));
											String Expected6c=element.getAttribute("value");
											
											element= driverUtil.waitForElementToBeAppear(By.xpath(txtMax2));
											String Expected6a=element.getAttribute("value");
											
											element= driverUtil.waitForElementToBeAppear(By.xpath(txtMax3));
											String Expected6d=element.getAttribute("value");
											
											element= driverUtil.waitForElementToBeAppear(By.xpath(EFT));
											String EFT6=element.getAttribute("value");
											
											element= driverUtil.waitForElementToBeAppear(By.xpath(Cheque));
											String Cheque6=element.getAttribute("value");
											
											element= driverUtil.waitForElementToBeAppear(By.xpath(SingleAuthLimit));
											String AuthLimit6= element.getAttribute("value");
											
											element= driverUtil.getDriver().findElement(By.xpath(SingleChkLimit));
											String strSingleChkLimit6= element.getAttribute("value");
											
												if ((Expected6c.equals("24M")) & (Expected6a.equals("14M")) & (Expected6d.equals("12M")))  {
												
												ExtentManager.reportlog(LogStatus.PASS, "Amount is populated as expected", true);
									    
												}
												
												if ((EFT6.equals("13D")) & (Cheque6.equals("13D")) & (AuthLimit6.equals("100000.00")) & (strSingleChkLimit6.equals("750000.00")) ) {
													
													ExtentManager.reportlog(LogStatus.PASS, "EFT & Check Amount is : "+EFT, true);
													ExtentManager.reportlog(LogStatus.PASS, "Auth Limit & Single Chk Limit Amount is : "+SingleChkLimit , true);
												}
												
							
								break;
						
				}
				
						element= driverUtil.getWebElement(By.xpath(ButtonClose));
						element.click();
				
			}
				
	}

		
	
