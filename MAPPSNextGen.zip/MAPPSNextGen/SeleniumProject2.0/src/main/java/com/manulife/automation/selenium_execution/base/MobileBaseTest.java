package com.manulife.automation.selenium_execution.base;


import org.testng.annotations.BeforeMethod;
import com.manulife.automation.selenium_core.base.CoreMobileBaseTest;
import com.manulife.automation.selenium_execution.utils.MobileDriverUtil;

/**
 * This class will be extended for the test case class where mobile test case will be written
 */
public class MobileBaseTest extends CoreMobileBaseTest<MobileDriverUtil>{
  	
	@BeforeMethod (alwaysRun=true, description = "initialize mobile app" )
  	@Override
  	public void init() {
  		super.init();
  		this.mobileDriverUtil = new MobileDriverUtil(getDriver());
  	}
  		
  	
}
