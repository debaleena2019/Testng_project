package com.manulife.automation.selenium_execution.base;

import org.testng.annotations.BeforeMethod;
import com.manulife.automation.selenium_core.base.CoreBaseTest;
import com.manulife.automation.selenium_execution.utils.DriverUtil;

/**
 * This class will be extended for the test case class where web browser test case will be written
 */
public class BaseTest extends CoreBaseTest<DriverUtil>{
	
  	@BeforeMethod (alwaysRun=true, description = "initialize webdriver" )
  	@Override
  	public void init() {
  		super.init();
  		this.driverUtil = new DriverUtil(getDriver());
  	} 
  	  	
}
