package com.manulife.automation.selenium_execution.pages.web;

import org.openqa.selenium.By;

import com.manulife.automation.selenium_execution.pages.web.JobSearchPage;
import com.manulife.automation.selenium_execution.utils.DriverUtil;

public class SearchMFCentralPage {

	private DriverUtil driverUtil;
	
	private String inputSearchXPath = "//input[@placeholder='Begin your search...']";
	private String searchXPath = "//a[@class='CoveoSearchButton']";
	private String searchLinkXPath = "//a[contains(@href, 'https://mfcentral.manulife.com/cms__Main?name=My-Career-Job-Search')]";
	private String searchNoRsltXPath = "//*[@id='global-search']/div[2]/p";
	
	public SearchMFCentralPage(DriverUtil driverUtil) throws Exception{			
		this.driverUtil = driverUtil;
		this.driverUtil.waitForJQueryToLoad();
	}	
	
	public void inputSearchText(String txtSearch) throws Exception{				
		this.driverUtil.sendKeys(By.xpath(inputSearchXPath), txtSearch);
	}		
	
	public void clickSearch() throws Exception{				
		this.driverUtil.click(By.xpath(searchXPath));
	}		
	
	public JobSearchPage selectLinkFromList() throws Exception{				
		this.driverUtil.clickWithoutScroll(By.xpath(searchLinkXPath));
		return  new JobSearchPage(this.driverUtil);				
	}
	
	public String searchNoRsltXPath() throws Exception{
		return this.driverUtil.getText(By.xpath(searchNoRsltXPath));
	}
	
	public boolean isSearchLinkPresent() throws Exception{
		return this.driverUtil.checkElementPresent(By.xpath(searchLinkXPath));
	}
	
}
