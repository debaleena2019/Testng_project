package com.manulife.automation.selenium_execution.pages.web;

import org.openqa.selenium.By;

import com.manulife.automation.selenium_execution.utils.DriverUtil;

public class JobSearchPage {	
	private DriverUtil driverUtil;
	
	private String globalOpportunitiesXPath = "a[contains(@href, 'jobsearch')]";
	private String pageBodyTagName = "body";
	
	public JobSearchPage(DriverUtil driverUtil) throws Exception{		
		this.driverUtil = driverUtil;		
		this.driverUtil.waitForJQueryToLoad();
	}		
	
	public String getPageText() throws Exception{
		return this.driverUtil.getText(By.tagName(pageBodyTagName));					
	}
	
}