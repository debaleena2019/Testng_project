package com.manulife.automation.selenium_execution.pages.web;

import org.openqa.selenium.By;
import com.manulife.automation.selenium_execution.utils.DriverUtil;


public class ManulifePage {
	private DriverUtil driverUtil;
	
	private String titlePageXPath = "//div[@class='slider-content-holder']/h1";
	
	
	public ManulifePage(DriverUtil driverUtil) {	
		this.driverUtil = driverUtil;
	}

	public String getTitle() throws Exception {
		return this.driverUtil.getText(By.xpath(titlePageXPath));
	}
}
