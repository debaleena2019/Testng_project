/**
 * 
 */
package com.manulife.automation.selenium_execution.pages.web;

import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import com.manulife.automation.selenium_core.utils.ImageCompareUtil;
import com.manulife.automation.selenium_core.utils.reports.ExtentManager;
import com.manulife.automation.selenium_execution.utils.DriverUtil;
import com.relevantcodes.extentreports.LogStatus;

public class DownloadingBrochure {	
	private DriverUtil driverUtil;
	
	ImageCompareUtil imageCompare = new ImageCompareUtil();
	private String selectProvinceXpth = "//*[@id='province_code']";
	private String provinceStart = "//*[@value='";
	private String provinceEnd = "']";
	private String btnSave = "save_selection";
	private String clickBrochure = "//*[@class='cta-content']/a";
	private String clickShop = "//*[@class='material-icons material-arrow-right']";
	private String healthInsuranceXpth = "//*[@href='/health-insurance.html']";
	private String lifeInsuranceXpth = "//*[@href='/life-insurance.html']"; 
	
	private String flexcareHealth = "//*[@value='Flexcare® Health and Dental Insurance']";
	private String followMe = "//*[@value='FollowMe™ Health and Dental Insurance']";
	private String critical = "//*[@value='CoverMe® Critical Illness Insurance']";
	
	private String lifeTermInsurance = "//*[@value='CoverMe® Term Life Insurance']";
	private String guareentedLifeInsurance = "//*[@value='CoverMe® Guaranteed Issue Life Insurance']";
	private String easyLifeInsurance = "//*[@value='CoverMe® Easy Issue Life Insurance']";
	private String followMeLifeInsurance = "//*[@value='FollowMe™ Life Insurance']";
	
	private String firstName= "name";
	private String email = "email";
	private String coverMeBrochureSubmit = "btnSubmit";
	
	public DownloadingBrochure(DriverUtil driverUtil) throws Exception {
		this.driverUtil = driverUtil;		
		this.driverUtil.waitForJQueryToLoad();
	}
	
	public void selectProvince(Map<String,String> data) throws Exception{
		String province = data.get("Provice");
		WebElement element = driverUtil.waitForElementToBeClickable(By.xpath(selectProvinceXpth));
		if(element!=null) {
			element.click();
			element = driverUtil.waitForElementToBeClickable(By.xpath(provinceStart+province+provinceEnd));
			element.click();
			element = driverUtil.waitForElementToBeClickable(By.id(btnSave));
			element.click();
			ExtentManager.reportlog(LogStatus.PASS, "Selected the province successfully", true);
			Thread.sleep(2000);
		}
		
	}
	
	public void selectShopType(Map<String,String> data) throws Exception{
		String typeInsurance = data.get("TypeofInsurance");
		WebElement element = driverUtil.waitForElementToBeClickable(By.xpath(clickShop));
		element.click();
		typeInsurance = typeInsurance.toLowerCase();
		if(typeInsurance.contains("health")) {
			element = driverUtil.waitForElementToBeClickable(By.xpath(healthInsuranceXpth));
			if(element!=null) {
				element.click();
			}
			ExtentManager.reportlog(LogStatus.PASS, "Selected the health insurance successfully", true);
		}else if(typeInsurance.contains("life")) {
			element = driverUtil.waitForElementToBeClickable(By.xpath(lifeInsuranceXpth));
			if(element!=null) {
				element.click();
			}
			ExtentManager.reportlog(LogStatus.PASS, "Selected the life insurance successfully", true);
		}else{
			ExtentManager.reportlog(LogStatus.FAIL, "Wrong type of Selection", true);
		}
	}

	public void selectSubType(Map<String, String> data) {
		// TODO Auto-generated method stub
		WebElement element = driverUtil.waitForElementToBeClickable(By.xpath(clickBrochure));
		if(element!=null)
			element.click();
		String subTypes = data.get("SubType");
		subTypes = subTypes.toLowerCase();
		if(subTypes.contains("flexcare")) {
			element = driverUtil.waitForElementToBeClickable(By.xpath(flexcareHealth));
			if(element!=null)
				element.click();
		}else if(subTypes.contains("followMe")) {
			element = driverUtil.waitForElementToBeClickable(By.xpath(followMe));
			if(element!=null)
				element.click();
		}else if(subTypes.contains("critical")) {
			element = driverUtil.waitForElementToBeClickable(By.xpath(critical));
			if(element!=null)
				element.click();
		}else if(subTypes.contains("term")) {
			element = driverUtil.waitForElementToBeClickable(By.xpath(lifeTermInsurance));
			if(element!=null)
				element.click();
		}else if(subTypes.contains("guaran")) {
			element = driverUtil.waitForElementToBeClickable(By.xpath(guareentedLifeInsurance));
			if(element!=null)
				element.click();
		}else if(subTypes.contains("easy")) {
			element = driverUtil.waitForElementToBeClickable(By.xpath(easyLifeInsurance));
			if(element!=null)
				element.click();
		}else if(subTypes.contains("followme life")) {
			element = driverUtil.waitForElementToBeClickable(By.xpath(followMeLifeInsurance));
			if(element!=null)
				element.click();
		}
		
		element = driverUtil.waitForElementToBeClickable(By.id(firstName));
		element.click();
		element.sendKeys(data.get("Name"));
		element = driverUtil.waitForElementToBeClickable(By.id(email));
		element.click();
		element.sendKeys(data.get("Email"));
		element = driverUtil.waitForElementToBeClickable(By.id(coverMeBrochureSubmit));
		element.click();
	}
	
	
}