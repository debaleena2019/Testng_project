package com.manulife.automation.selenium_execution.pages.web;

import org.openqa.selenium.By;

import com.manulife.automation.selenium_execution.utils.DriverUtil;

public class HomeMFCentralPage{
	private DriverUtil driverUtil;
			
	private String uiLabelSearchXPath = "//li[@id='uiLabelSearch']";
	private String uiLabelLaunchPadXPath = "//li[@id='uiLabelLaunchPad']"; 
	
	public HomeMFCentralPage(DriverUtil driverUtil) throws Exception{			
		this.driverUtil = driverUtil;
		this.driverUtil.waitForJQueryToLoad();
	}			
		
	public SearchMFCentralPage goToSearch() throws Exception{
		this.driverUtil.click(By.xpath(uiLabelSearchXPath));
		return new SearchMFCentralPage(this.driverUtil);			
	}		
		
	public void goToMyTools() throws Exception{		
		this.driverUtil.click(By.xpath(uiLabelLaunchPadXPath));
	}	
}