package com.manulife.automation.selenium_execution.common;


public final class TestType {

	public static final String SMOKE = "Smoke";
	public static final String PDFUTIL = "PDFUtil";
	public static final String IMAGEUTIL = "ImageUtil";
	public static final String WEBBROWSER = "webBrowser";
	public static final String LOCALIZATION = "localization";
	public static final String SUBITERATION = "subIteration";

}