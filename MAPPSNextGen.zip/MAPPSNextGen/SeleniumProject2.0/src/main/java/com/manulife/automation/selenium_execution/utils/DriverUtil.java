package com.manulife.automation.selenium_execution.utils;


import java.util.Set;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.manulife.automation.selenium_core.driver.web.DriverThreadManager;
import com.manulife.automation.selenium_core.utils.DriverUtilBase;
/**
 * Grouping of all WebDriver Util wrapper methods
 *
 * @author Sarbjit Sandhu
 */
public class DriverUtil extends DriverUtilBase {
	protected static final Logger logger = LogManager.getLogger(DriverUtil.class.getName());

	/**
	 * DriverUtil Class Constructor
	 *
	 * @param newDriver - WebDriver to be used locator this class
	 */
	public DriverUtil(WebDriver newDriver) {
		super(newDriver);
		this.driver = newDriver;
	}

	public WebDriver getDriver()
	{
		return DriverThreadManager.getDriverStatic();
	} 


	public void switchToNextTab() throws Exception {
		driver = getDriver();
		String parent = driver.getWindowHandle();
		Set<String> allWindows = driver.getWindowHandles();
		int count = allWindows.size();
		System.out.println(count);


		if(count==1)

		{
			String newWindow=driver.getWindowHandle();
			driver.switchTo().window(newWindow);
			System.out.println("# of windows is only one - hence no switching");
		}else 
		{

			System.out.println("# of windows > 1");

			for (String child : allWindows) {
				if (!parent.equalsIgnoreCase(child)) 
				{
					driver.switchTo().window(child);
					Thread.sleep(3000);
					System.out.println(driver.getTitle());
					//URL = getUrl();
					//System.out.println(URL);
					//driver.close();
					//driver.switchTo().window(child);
					Thread.sleep(2000);
				}
			}}

	}
	
	public void switchToNextWindowByTitle(String title) throws Exception {
		driver = getDriver();
		
		String parent = driver.getWindowHandle();
		Set<String> allWindows = driver.getWindowHandles();
		int count = allWindows.size();
		System.out.println(count);

		if(count==1)

		{
			String newWindow=driver.getWindowHandle();
			driver.switchTo().window(newWindow);
			System.out.println("# of windows is only one - hence no switching");
		}else 
		{

			System.out.println("# of windows > 1");

			for (String child : allWindows) {
				if (!parent.equalsIgnoreCase(child)) 
				{
					if (!driver.getTitle().contains("Add Table"))
					{
					driver.switchTo().window(child);
					Thread.sleep(3000);
					System.out.println(driver.getTitle());
					//URL = getUrl();
					//System.out.println(URL);
					//driver.close();
					//driver.switchTo().window(child);
					Thread.sleep(2000);
					}
				}
			}}
	}
		public void switchToNextWindowByTitle1(String title) throws Exception {
			driver = getDriver();
			
			String parent = driver.getWindowHandle();
			Set<String> allWindows = driver.getWindowHandles();
			int count = allWindows.size();
			System.out.println(count);

			if(count==1)

			{
				String newWindow=driver.getWindowHandle();
				driver.switchTo().window(newWindow);
				System.out.println("# of windows is only one - hence no switching");
			}else 
			{

				System.out.println("# of windows > 1");

				for (String child : allWindows) {
					if (!parent.equalsIgnoreCase(child)) 
					{
						if (!driver.getTitle().contains("Narr..."))
						{
						driver.switchTo().window(child);
						Thread.sleep(3000);
						System.out.println(driver.getTitle());
						//URL = getUrl();
						//System.out.println(URL);
						//driver.close();
						//driver.switchTo().window(child);
						Thread.sleep(2000);
						}
					}
				}}

	}
		
		public void switchToNextWindowByTitle2(String title) throws Exception {
			driver = getDriver();
			System.out.println("Page Info  -----------");
			System.out.println(driver.findElement(By.xpath("//*")).getText());
			String parent = driver.getWindowHandle();
			Set<String> allWindows = driver.getWindowHandles();
			int count = allWindows.size();
			System.out.println(count);

			if(count==1)

			{
				String newWindow=driver.getWindowHandle();
				driver.switchTo().window(newWindow);
				System.out.println("# of windows is only one - hence no switching");
			}else 
			{

				System.out.println("# of windows > 1");

				for (String child : allWindows) {
					if (!parent.equalsIgnoreCase(child)) 
//					{
//						if (driver.getTitle().contains("Claim Locks"))
//						{
							driver.switchTo().window(child);
							Thread.sleep(3000);
							System.out.println("Page Info  -----------");
							System.out.println(driver.findElement(By.xpath("//*")).getText());
							//URL = getUrl();
							//System.out.println(URL);
							//driver.close();
							//driver.switchTo().window(child);
							Thread.sleep(2000);
							//}
						//}
				}}

	}
		


}
