package com.manulife.automation.selenium_execution.tests.web;

import java.util.List;

import org.testng.Assert;
import org.testng.annotations.Test;
import com.manulife.automation.selenium_core.utils.ImageCompareUtil;
import com.manulife.automation.selenium_execution.base.BaseTest;
import com.manulife.automation.selenium_execution.common.TestType;
import com.manulife.automation.selenium_execution.pages.web.AutomationPracticePage;



public class ImageCompareUtilTest extends BaseTest{	
		
		@Override
		public void initializeTest() throws Exception {
			super.initializeTest("en","automationPractice");
		}
		
		ImageCompareUtil imageCompare = new ImageCompareUtil();
		
		@Test (testName = "checkScreenshotImageAgainstSavedImageComparisonTest", groups={TestType.WEBBROWSER, TestType.IMAGEUTIL} , description ="Screen shot image comparison test")
		public void checkScreenshotImageComparisonTest() throws Exception {
			AutomationPracticePage automationPage = new AutomationPracticePage(driverUtil);			
			Assert.assertTrue(automationPage.getMatchedPercentage().size()>0);			
		}

		@Test (testName = "checkImageAgainstSavedImageComparisonTest", groups={TestType.WEBBROWSER, TestType.IMAGEUTIL}, description ="Image against saved image comparison test")
		public void checkImageComparisonTest() throws Exception {
			List<Double> matchPercentage = imageCompare.compareTwoImagesForSimilarity("images/logo.jpg", "src/test/resources/images/store.jpg");		
			Assert.assertTrue(matchPercentage.size()>0);							
		}		

}
