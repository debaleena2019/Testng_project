package com.manulife.automation.selenium_execution.tests.mobile.web;

import org.testng.annotations.Test;
import com.manulife.automation.datareader.excel.ExcelUtil;
import com.manulife.automation.selenium_execution.base.BaseTest;
import com.manulife.automation.selenium_execution.common.MobileTestType;
import com.manulife.automation.selenium_execution.common.TestType;
import com.manulife.automation.selenium_execution.pages.web.AutomationPracticePage;

public class MobileBrowserTest extends BaseTest {
	
	ExcelUtil excelUtil = new ExcelUtil("src/test/resources/testdata/testDataSheet.xlsx");
	
	@Override
	public void initializeTest() throws Exception {
		// TODO Auto-generated method stub
		super.initializeTest("en", "automationPractice");
	}
	
	@Test (groups = {MobileTestType.MOBILEWEB, TestType.WEBBROWSER}, description = "Mobile Browser Test")	
	public void mobileBrowserTest() throws Exception{	
		AutomationPracticePage automationPractice = new AutomationPracticePage(this.driverUtil);
		
		//Verify the Menu Category
		automationPractice.verifyMenuCategory();
	}
}