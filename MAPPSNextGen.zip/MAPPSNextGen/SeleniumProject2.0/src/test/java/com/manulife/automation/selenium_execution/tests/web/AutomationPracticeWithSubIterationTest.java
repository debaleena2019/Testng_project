package com.manulife.automation.selenium_execution.tests.web;

import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import com.manulife.automation.datareader.excel.ExcelUtil;
import com.manulife.automation.selenium_core.utils.reports.ExtentManager;
import com.manulife.automation.selenium_execution.base.BaseTest;
import com.manulife.automation.selenium_execution.common.TestType;
import com.manulife.automation.selenium_execution.pages.web.ProductDetailsPage;
import com.manulife.automation.selenium_execution.pages.web.ShoppingCartPage;
import com.relevantcodes.extentreports.LogStatus;

public class AutomationPracticeWithSubIterationTest extends BaseTest {
	
	@Override
	public void initializeTest() throws Exception {
		super.initializeTest("en","automationPractice");
	}
	
	ExcelUtil excelUtil = new ExcelUtil("src/test/resources/testdata/testDataSheet.xlsx");
	
	//Creating this DataProvider to read the value from TestData Excel File
	@DataProvider(name="readDataWithSubIteration")
	public Object[][] getExcelDatafromSheet(Method method) throws Exception{
		 //Getting the Data Row against the Test Case name and store it within an array
		 Object[][] testObjArray = excelUtil.getMatchingTestCasesWithSubIteration("subIterationTest",method.getName());
		 return (testObjArray);
	}
	
	@Test(dataProvider="readDataWithSubIteration", groups= {TestType.WEBBROWSER, TestType.SUBITERATION, TestType.SMOKE}, description="Add to cart using subiteration test")
	//Within this Test we are passing only one Parameter as HashMap. To get the value from data sheet we just need use this Map with Column name as Key.
	public void addToCartWithSubIterationTest(Map<Integer,Map <String,String>> iterationData) throws Exception{
		
		Map<String,String> data = new HashMap<>();
		ProductDetailsPage productPage = new ProductDetailsPage(driverUtil);
		//Set SubIteration 1
		data = iterationData.get(1);
		productPage.selectAndAddProductWithinCart(data.get("Product Name"), data.get("Quantity"), data.get("Size"));
		productPage.continueShopping();
		
		//Set SubIteration 2
		data = iterationData.get(2);
		productPage.selectAndAddProductWithinCart(data.get("Product Name"), data.get("Quantity"), data.get("Size"));
		ShoppingCartPage shoppingCartPage = productPage.proceedToCheckOut();
		
		if(shoppingCartPage.verifyShoppingCart().equalsIgnoreCase("Your shopping cart")) {
			ExtentManager.reportlog(LogStatus.PASS, "Product Page " + "Cart details is displayed", true);
		}
		else {
			ExtentManager.reportlog(LogStatus.FAIL, "Product Page " + "Cart details is not displayed", true);
		}
		
		shoppingCartPage.deleteCartItem();
	}
	
}