package com.manulife.automation.selenium_execution.tests.web;

import static org.testng.Assert.assertEquals;
import org.testng.annotations.Test;
import com.manulife.automation.reader.pdf.PdfUtil;
import com.manulife.automation.selenium_execution.common.TestType;
import com.manulife.automation.selenium_execution.base.BaseTest;

public class PdfUtilTest extends BaseTest {
	
	@Override
	public void initializeTest() throws Exception {
		super.initializeTest("en","initUrl");
	}
	
	PdfUtil pdfUtil = new PdfUtil("src/test/resources/pdffiles/Travelocity.pdf");
	
	@Test (testName = "verifyPDFPageCount", priority = 0, groups = {TestType.WEBBROWSER, TestType.PDFUTIL, TestType.SMOKE}, description = "Verify PDF page" )	
	public void verifyPdfPageTest() throws Exception{		
		assertEquals(pdfUtil.getNumberOfPages(), 3);			
	}
	
	@Test (testName = "verifyPDFText", priority = 1, groups = {TestType.WEBBROWSER, TestType.PDFUTIL}, description = "Verify PDF text")	
	public void verifyTextTest() throws Exception{		
		assertEquals(pdfUtil.verifyTextWithinWholePDF("Tathagata"), false);			
	}
	
	@Test (testName = "verifyPDFForms", priority = 2, groups = {TestType.WEBBROWSER, TestType.PDFUTIL}, description = "Verify PDF forms")	
	public void verifyTextInPDFFormTest() throws Exception{	
		PdfUtil pdfForm = new PdfUtil("src/test/resources/pdffiles/PDFVerification.pdf");
		assertEquals(pdfForm.verifyTextWithinPDFForm("MALCOLM WAKEFIELD"), true);			
	}
	
	@Test (testName = "getWordCount", priority = 3, groups = {TestType.WEBBROWSER, TestType.PDFUTIL}, description = "Get word count")	
	public void getWordCountTest() throws Exception{		
		assertEquals(pdfUtil.getWordCountFromWholePDF("Campaign"), 28);			
	}
	
	
}