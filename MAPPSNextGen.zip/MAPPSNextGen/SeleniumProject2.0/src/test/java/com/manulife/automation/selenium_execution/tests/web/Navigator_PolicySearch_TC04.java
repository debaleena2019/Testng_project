package com.manulife.automation.selenium_execution.tests.web;

import java.lang.reflect.Method;
import java.util.Map;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.manulife.automation.datareader.excel.ExcelUtil;
import com.manulife.automation.selenium_execution.base.BaseTest;
import com.manulife.automation.selenium_execution.common.TestType;
import com.manulife.automation.selenium_execution.pages.web.PolicySearch;

public class Navigator_PolicySearch_TC04 extends BaseTest {
	
	ExcelUtil excelUtil = new ExcelUtil("src/test/resources/testdata/testDataSheet.xlsx");
	
	@Override
	public void initializeTest() throws Exception {
		String language = getLanguage();
		String applicationUrl = null;
		String lang = null;
		//int CountTab ;
		
		//Based on the language it will pick up the actual URL
		
			applicationUrl = "initUrl";
			lang = "fr";
		
		
		super.initializeTest(lang,applicationUrl);
	}
	
	//Creating this DataProvider to read the value from TestData Excel File
	@DataProvider(name="readDataFromExcel")
	public Object[][] getExcelDatafromSheet(Method method) throws Exception{
		//Getting the Data Row against the Test Case name and store it within an array, if the french config or english config...	
		 Object[][] testObjArray = excelUtil.getAllMatchingTestCases("BrochureEnglish", method.getName());
		 return (testObjArray);	 
		 
	}
	
	@DataProvider(name="readMultipleDataFromExcel")
	public Object[][] getMultipleExcelDatafromSheet(Method method) throws Exception{
		//Getting the Data Row against the Test Case name and store it within an array, if the french config or english config...	
		 Object[][] testObjArray = excelUtil.getAllMatchingTestCases("BrochureEnglish", method.getName());
		 return (testObjArray); 
		 
	}
	
	@Test (dataProvider="readMultipleDataFromExcel", groups = {TestType.WEBBROWSER, TestType.LOCALIZATION}, description="Base Url MultiLanguage Test")	
	public void NavigatorPolicySearch_TC04(Map<String,String> data) throws Exception{		
		PolicySearch PolicySerachModule = new PolicySearch(this.driverUtil);
		PolicySerachModule.ClickOnNavigator(data);
		PolicySerachModule.ClickOnPolicySearchLink(data);
		Thread.sleep(5000);
		driverUtil.switchToNextTab();
		driverUtil.maximizeBrowser();
		PolicySerachModule.ClickOnPolicySearchButtonTC04(data);
				
        } 
	
		
	
	
	
}

		
