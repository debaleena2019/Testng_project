package com.manulife.automation.selenium_execution.tests.web;

import java.lang.reflect.Method;
import java.util.Map;

import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.manulife.automation.datareader.excel.ExcelUtil;
import com.manulife.automation.selenium_execution.common.TestType;
import com.manulife.automation.selenium_execution.base.BaseTest;
import com.manulife.automation.selenium_execution.pages.web.ManulifePage;

public class BaseUrlTest extends BaseTest {
	
	@Override
	public void initializeTest() throws Exception {
		super.initializeTest("en","baseUrl");
	}
	
	ExcelUtil excelUtil = new ExcelUtil("src/test/resources/testdata/testDataSheet.xlsx");
	
	//Creating this DataProvider to read the value from TestData Excel File
	@DataProvider(name="readDataFromExcel")
	public Object[][] getExcelDatafromSheet(Method method) throws Exception{
		 //Getting the Data Row against the Test Case name and store it within an array
		 Object[][] testObjArray = excelUtil.getAllMatchingTestCases("verifyTitle",method.getName());
		 return (testObjArray);
	}
	
	@Test (dataProvider="readDataFromExcel", groups= {TestType.WEBBROWSER, TestType.SMOKE}, description="Base url Test")	
	public void baseUrlTest(Map<String,String> data) throws Exception{		
		ManulifePage manulifePage = new ManulifePage(driverUtil);
		
		//Verify header text "Get the information you need"
		Assert.assertEquals(manulifePage.getTitle(), data.get("Title"));			
	}
}