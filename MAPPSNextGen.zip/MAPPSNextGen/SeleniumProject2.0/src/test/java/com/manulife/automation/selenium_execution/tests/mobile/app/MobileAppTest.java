package com.manulife.automation.selenium_execution.tests.mobile.app;

import org.testng.annotations.Test;
import com.manulife.automation.selenium_execution.base.MobileBaseTest;
import com.manulife.automation.selenium_execution.common.MobileTestType;
import com.manulife.automation.selenium_execution.pages.mobile.GroupBenefitsPage;

public class MobileAppTest extends MobileBaseTest {
	
	
	@Test (groups = MobileTestType.MOBILEAPP, description = "Mobile App Test")	
	public void mobileAppTest() throws Exception{		
		GroupBenefitsPage groupBenefitPage = new GroupBenefitsPage(this.mobileDriverUtil);
		
		//Open Group Benefit Link		
		groupBenefitPage.goToGroupBenefits();
		//Login to Application
		groupBenefitPage.loginToApplication();
	}
}