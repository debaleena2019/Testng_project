package com.manulife.automation.selenium_execution.tests.web;

import java.lang.reflect.Method;
import java.util.Map;

import org.openqa.selenium.By;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.manulife.automation.datareader.excel.ExcelUtil;
import com.manulife.automation.selenium_execution.base.BaseTest;
import com.manulife.automation.selenium_execution.common.TestType;
import com.manulife.automation.selenium_execution.pages.web.Admin;
import com.manulife.automation.selenium_execution.pages.web.Utilitis;

public class Navigator_Admin_TC07 extends BaseTest {
	
	ExcelUtil excelUtil = new ExcelUtil("src/test/resources/testdata/testDataSheet.xlsx");
	
	@Override
	public void initializeTest() throws Exception {
		String language = getLanguage();
		String applicationUrl = null;
		String lang = null;
		//int CountTab ;ABC	
		
		//Based on the language it will pick up the actual URL
		
			applicationUrl = "initUrl";
			lang = "fr";
		
		//driverUtil.deleteAllCookies();
		super.initializeTest(lang,applicationUrl);
	}
	
	//Creating this DataProvider to read the value from TestData Excel File
	@DataProvider(name="readDataFromExcel")
	public Object[][] getExcelDatafromSheet(Method method) throws Exception{
		//Getting the Data Row against the Test Case name and store it within an array, if the french config or english config...	
		 Object[][] testObjArray = excelUtil.getAllMatchingTestCases("BrochureEnglish", method.getName());
		 return (testObjArray);	 
		 
	}
	
	@DataProvider(name="readMultipleDataFromExcel")
	public Object[][] getMultipleExcelDatafromSheet(Method method) throws Exception{
		//Getting the Data Row against the Test Case name and store it within an array, if the french config or english config...	
		 Object[][] testObjArray = excelUtil.getAllMatchingTestCases("BrochureEnglish", method.getName());
		 return (testObjArray); 
		 
	}
	
	@Test (dataProvider="readMultipleDataFromExcel", groups = {TestType.WEBBROWSER, TestType.LOCALIZATION}, description="Base Url MultiLanguage Test")	
	public void Navigator_Admin_TC07(Map<String,String> data) throws Exception{		
		Admin Adm = new Admin(this.driverUtil);
		
		Adm.ClickOnNavigator(data);
		Adm.ClickOnAdmin(data);
		Thread.sleep(2000);
		driverUtil.switchToNextTab();
		driverUtil.maximizeBrowser();
		Adm.PaymentType(data);
		//Adm.ClickonClosed(data);
		
		Thread.sleep(2000);
		
		
	} 
}

		
