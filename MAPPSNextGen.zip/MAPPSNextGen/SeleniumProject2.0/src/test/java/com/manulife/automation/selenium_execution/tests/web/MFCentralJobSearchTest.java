package com.manulife.automation.selenium_execution.tests.web;

import java.lang.reflect.Method;
import java.util.Map;

import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.manulife.automation.datareader.excel.ExcelUtil;
import com.manulife.automation.selenium_execution.common.TestType;
import com.manulife.automation.selenium_execution.base.BaseTest;
import com.manulife.automation.selenium_execution.pages.web.HomeMFCentralPage;
import com.manulife.automation.selenium_execution.pages.web.JobSearchPage;
import com.manulife.automation.selenium_execution.pages.web.SearchMFCentralPage;

public class MFCentralJobSearchTest extends BaseTest {
	
	@Override
	public void initializeTest() throws Exception {
		super.initializeTest("en","initUrl");
	}
	
	ExcelUtil excelUtil = new ExcelUtil("src/test/resources/testdata/testDataSheet.xlsx");
	
	//Creating this DataProvider to read the value from TestData Excel File
	@DataProvider(name="readDataFromExcel")
	public Object[][] getExcelDatafromSheet(Method method) throws Exception{
		 //Getting the Data Row against the Test Case name and store it within an array
		 Object[][] testObjArray = excelUtil.getAllMatchingTestCases("jobSearch", method.getName());
		 return (testObjArray);
	}
	
	//Creating this DataProvider to read the value from TestData Excel File where multiple Test Case entries are present
	@DataProvider(name="readMultipleDataFromExcel")
	public Object[][] getMultipleExcelDatafromSheet(Method method) throws Exception{
		 //Getting all the Data Rows against the Test Case name and store it within an array
		 Object[][] testObjArray = excelUtil.getAllMatchingTestCases("jobSearch", method.getName());
		 return (testObjArray);
	}
	
	//Navigate to Job Search page by searching from Home Page	
	@Test(dataProvider="readMultipleDataFromExcel", groups= {TestType.WEBBROWSER, TestType.SMOKE}, description="Job search test")
	//Within this Test we are passing only one Parameter as HashMap. To get the value from data sheet we just need use this Map with Column name as Key.
	public void jobSearchTest(Map <String,String> data) throws Exception{
		HomeMFCentralPage homePage = new HomeMFCentralPage(driverUtil);				
		//Navigate to search page		
		SearchMFCentralPage searchPage = homePage.goToSearch();				
		
		//Enter search text	retrieved from Excel Sheet	
		searchPage.inputSearchText(data.get("Search Criteria"));			
		searchPage.clickSearch();				
		
		//Click on the MFCentral Job Search link from the list of options		
		JobSearchPage jobSearchPage = searchPage.selectLinkFromList();		
		
		//Verify page displays "Job Search"		
		Assert.assertTrue(jobSearchPage.getPageText().contains(data.get("Search Criteria")));		//Getting the value for Search Criteria Column from the Excel Data Sheet		
	}
	
	//Using the DataProvider which will read only one row from excel
	@Test(dataProvider="readDataFromExcel", groups= {TestType.WEBBROWSER, TestType.SMOKE}, description="Job search negative test")
	//Declaring the parameter which will be passed from DataProvider. 
	//It will automatically map the arguments with all the columns in a serial manner.
	public void jobSearchNegativeTest(Map <String,String> data) throws Exception{
		HomeMFCentralPage homePage = new HomeMFCentralPage(driverUtil);				
		//Navigate to search page		
		SearchMFCentralPage searchPage = homePage.goToSearch();				
		
		//Enter search text retrieved from Excel sheet through DataProvider		
		searchPage.inputSearchText(data.get("Search Criteria"));			
		searchPage.clickSearch();				
		
		// Check search results not displayed
		Assert.assertFalse(searchPage.isSearchLinkPresent());
	}
}